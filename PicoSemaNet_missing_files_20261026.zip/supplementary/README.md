# Supplementary evidence added on 26 October 2026

This directory supplies local reproducibility materials that were absent from
the repository at commit `d16c386052b59ab86e28630b4ee1f99f093265f8`.
Every pre-existing repository file is preserved unchanged, including the root
README, source files, configurations, results, CITATION.cff, LICENSE and manifest.

## Contents

- `zenodo_v1.0.0/evidence/bf1_euclidean_20261009/`: original later CPU Euclidean-BF1
  evaluation scripts, per-image outputs, summaries and provenance.
- `zenodo_v1.0.0/evidence/current_configuration_20261009/`: the EC-free manuscript
  configuration mapping, original figure scripts, figure data and four figures.
- `zenodo_v1.0.0/evidence/verification_20260928/`: model parameter and counted-MAC
  verification script and recorded outputs.
- `zenodo_v1.0.0/evidence/fixed100_20261009/`: original 100-epoch control audit,
  logs, configurations and last checkpoints whose bytes differ from the best
  checkpoints already documented in the GitHub release.
- `zenodo_v1.0.0/tools/` and `zenodo_v1.0.0/validation/`: the separately documented
  portable replay helpers and validation receipts prepared for the Zenodo archive.
- `zenodo_v1.0.0/`: archive documentation, category-specific licensing and manifests.

## Relationship to the existing repository

The root README and `docs/PAPER_MAPPING.md` describe the original server-code
collection. Their statements about later BF1 outputs and figure/MAC scripts
being unavailable refer to that earlier collection; this directory adds those
later local materials without rewriting those files.

The archived BF1 files use the documented two-pixel Euclidean tolerance in the
320 x 320 evaluation space. Historical server BF1 values retain their original
distance convention. The primary objective remains Segmentation + FPFCS + KD
with EC and decoder DS disabled; EC-containing runs are retained as ablations.
No experiment has been retrained or result replaced by this addition.

## Completeness and how to use the materials

This is an addition-only supplement, not another full copy of the release.
Files whose exact content already exists in the Git tree or whose SHA-256 is
listed in the existing checkpoint release are not copied again. Duplicate
historical paths inside the new evidence are retained when they preserve the
original archival layout. Generated `.pyc` cache is excluded.

`FILE_MAP.json` maps all 700 original archive paths to the new files, an
identical pre-existing Git file, an existing release-checkpoint path, or the
excluded Python cache. The checkpoint availability comparison uses the
repository's `artifacts/experiments.json`; original weights were independently
verified when the Zenodo archive was prepared.

For an intact, directly runnable archival directory, download and extract the
complete fixed-version archive from **https://doi.org/10.5281/zenodo.23643500**,
then follow its `REPRODUCE.md`. The portable scripts and original manifest in
this supplement refer to that complete archive layout. Original historical
scripts also retain their original path assumptions. Do not run a partial
archival directory as if it were the complete release.

The existing GitHub checkpoint release remains at
https://github.com/zykmin1726982627-cloud/PicoSemaNet/releases/tag/v1.0.0.

## Licenses and verification

Original software is MIT. Author-created experiment records, figures and weights
in this supplement are CC BY 4.0; third-party rights remain unchanged. See
`zenodo_v1.0.0/RIGHTS.md`, `LICENSE-CODE.txt` and `LICENSE-DATA.txt` for scope and
license text. The repository's existing root LICENSE is unchanged.
ISIC source images and masks, manuscript sources, author portraits, credentials
and local workspace audit notes are not included.

`SHA256SUMS.txt` covers every file in this directory except itself. Historical
manifests copied inside `zenodo_v1.0.0/` describe the complete original archive;
use the new `SHA256SUMS.txt` for this addition-only tree.
