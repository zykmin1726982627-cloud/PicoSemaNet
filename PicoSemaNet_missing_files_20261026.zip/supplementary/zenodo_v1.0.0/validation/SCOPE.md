# Validation scope

All 47 added historical checkpoints match the original evaluation SHA-256 values. All 53 best checkpoints (47 historical and six fixed-100) were strictly loaded with the unmodified archived model code. The supplied teacher also matches the training queue hash. Both portable replay smoke checks used one real test image on CPU; they are not full-test-set results. The six-command training dry run preserved the original protocol and did not launch training.

The new full 520-image EC-free primary seed42 CPU replay matched archived CPU Dice, IoU and Euclidean BF1 within 1e-12. See primary_full520_replay.json. CPU Dice/IoU differ from the original GPU evaluation and do not replace those manuscript values.
