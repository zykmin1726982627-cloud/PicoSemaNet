# Reproduction guide

All commands run from the extracted release root. Python 3.11 or newer is sufficient for checksum verification. Model replay needs PyTorch, NumPy and Pillow. Archived training requirements are in `evidence/fixed100_20261009/raw/reproduction_code/requirements.txt`.

## 1. Verify the release

```text
python tools/verify_package.py
python tools/replay.py --list
```

`evidence/MANIFEST.sha256` independently authenticates the original supplement. The top-level manifest covers every release file except the manifest itself. Do not treat a modified evidence file as an original experiment record.

## 2. Obtain ISIC data

Official source: https://challenge.isic-archive.com/data/

Use ISIC 2018 Task 1 training images and ground-truth segmentation masks. The paper uses an internal 1,815/259/520 image split from the 2,594 released pairs; it does not use the hidden official challenge test.

Directory layout:

```text
ISIC2018/
  images/ISIC_0000000.jpg
  masks/ISIC_0000000_segmentation.png
```

Exact IDs: `evidence/data/ISIC2018/paper_split_70_10_20_seed20260912.json`.
Split SHA-256: `ff709315d972d602969d1da5815170abade7d0c08fa0d8c09264968a80df5228`.

The archived downloader in `evidence/bf1_euclidean_20261009/fetch_test_data.py` obtains only the 520 internal test pairs, not all training data. Its official ZIP CRC32 and file SHA-256 checks are documented in the evidence README. Follow the official dataset access conditions.

## 3. Replay a model on CPU

Install the original code requirements into an isolated environment. For the recorded CPU replay, the evidence records Python 3.13.5, PyTorch 2.14.0+cpu, NumPy 2.4.4, and Pillow 12.2.0. Consult the stored runtime records rather than assuming the broad minimum versions reproduce original arithmetic.

```text
python tools/replay.py --run fixed100/full_fpfcs_seed42 --dataset-root /path/to/ISIC2018 --output-dir /path/to/new-results
python tools/replay.py --run formal_paper_ablation_supplement_v1/s3b_no_edge_seed42 --dataset-root /path/to/ISIC2018 --output-dir /path/to/new-results
```

The helper explicitly uses the locked test IDs, 320 x 320 input, threshold 0.5, no auxiliary outputs, and Euclidean BF1. It validates the original checkpoint hash and writes per-image metrics and replay provenance. `--limit 1` is a smoke check only; only an untruncated 520-image replay evaluates the complete internal test set. Outputs never replace archived GPU results.

For the original 47-run CPU replay, the unmodified historical evaluator accepts portable root overrides:

```text
python evidence/bf1_euclidean_20261009/reevaluate.py --dataset-root /path/to/ISIC2018 --checkpoint-root checkpoints --output-dir /path/to/new-legacy-replay --threads 4 --batch-size 8
```

Do not use its `--pilot` option outside the original workspace; it references old local example paths. Its original group names are historical; use the current configuration mapping to identify EC-free primary runs.

## 4. Repeat the six matched training runs

Training is optional and is never started by the verification or replay helpers. It needs all 2,594 image/mask pairs and a suitable CUDA environment. The original records used RTX A5000, PyTorch 2.11.0+cu128, CUDA 12.8, AMP, and batch size 8.

```text
python tools/train_fixed100.py --data-root /path/to/ISIC2018 --output-dir /path/to/plan-preview --dry-run
python tools/train_fixed100.py --data-root /path/to/ISIC2018 --output-dir /path/to/new-training --run
```

The helper reuses the six actual archived commands, changes only executable/input/output/checkpoint paths and the explicit device/workers options, and preserves the seed pairing, 100 epochs, patience 101, KD and FPFCS settings. It runs the unmodified archived training code with an explicit locked split and the hash-verified shared teacher. It refuses a nonempty output directory, so the preview and actual run use different output folders. It saves the launch plan before training.

The original Linux queue imports `fcntl` and expects a Linux virtualenv layout; use the portable helper rather than assuming it works unchanged on Windows. Full training has not been repeated while preparing this release.

## 5. Figures, statistics, and accounting

- Current run mapping and source figures: `evidence/current_configuration_20261009/`.
- Plotting code and per-example provenance: its `figures/` and `figure_generation/` directories. Original absolute data/weight paths must be configured for a new machine.
- Paired test-image bootstrap inputs/results: `evidence/formal_paper_ablation_bootstrap_v1/` and `evidence/bootstrap_ablation.py`.
- Parameter and convolutional/linear MAC recount: `evidence/verification_20260928/`.
- Original result summaries: `evidence/formal_paper_*/`.
- Precise CPU BF1 definition and all 47 original replays: `evidence/bf1_euclidean_20261009/`.

The bootstrap intervals quantify test-image uncertainty conditional on trained models; they do not quantify independent training-run uncertainty. Three-seed spread is sample SD, not a significance test.
