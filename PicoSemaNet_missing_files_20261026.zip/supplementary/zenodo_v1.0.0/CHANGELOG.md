# v1.0.0 release preparation, 2026-10-25

- Preserved the 632-file experimental supplement and its original manifest unchanged under evidence/.
- Added all 47 historical best checkpoints, including primary models and the shared KD teacher, verified against archived SHA-256 values.
- Retained all six fixed-100 best and last checkpoints and all original metrics/logs.
- Added a current English README, portable verification/replay/training-launch helpers, a citation file, release file index, and metadata for a Zenodo deposit.
- Documented the current EC-free configuration and Euclidean BF1, with explicit mapping from historical labels.
- Did not retrain models or modify manuscript experiment values.
- Authors approved MIT for original software and CC BY 4.0 for author-created records, figures and weights on 2026-10-25; third-party terms remain unchanged. Zenodo publication is pending.
