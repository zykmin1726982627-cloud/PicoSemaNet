# Licenses

See RIGHTS.md for exact scope. Original software: MIT (LICENSE-CODE.txt). Author-created experiment records, figures and checkpoints: CC BY 4.0 (LICENSE-DATA.txt). Third-party materials retain their own terms.
