# PicoSemaNet / FPFCS reproducibility materials

Companion materials for **Full-Path Fixed-Channel Supervision for Compact Skin Lesion Segmentation**.

Authors: Yikuan Zheng, Bohe Fan, and Gaurav Gupta. Release: **v1.0.0**, prepared 2026-10-25.

Version DOI (registered when the Zenodo record is published): https://doi.org/10.5281/zenodo.23643500

## Start here

1. Read `REPRODUCE.md` for data preparation and runnable commands.
2. Run `python tools/verify_package.py` to verify all published checksums.
3. Use `python tools/replay.py --list` to find the archived model runs.
4. Cite the specific published version using `CITATION.cff` and its Zenodo DOI.

## What is included

- `evidence/`: the 632-file original supplement, preserved byte-for-byte. Its own checksum manifest still verifies independently.
- `checkpoints/`: all 47 historical best checkpoints, including the three EC-free primary PicoSemaNet runs, their controls, and the shared seed-42 Context Teacher. Original checkpoint hashes are recorded in `checkpoint_manifest.json`.
- `evidence/fixed100_20261009/raw/`: the six matched 100-epoch runs. Each has an original best and last checkpoint, configuration, training log, and test metrics (12 additional checkpoint files).
- Model, training, evaluation, split-preparation, bootstrap, and plotting code; fixed split IDs; per-run and per-image results; figure source data; original runtime records.
- `tools/`: portable release helpers. They write new outputs separately from archived evidence.
- `validation/`: checks performed while preparing this release, with their actual scope.

The 47 restored checkpoints were matched against the SHA-256 values already used in the archived evaluation. The teacher also matches the independent hash recorded by the six-run training queue.

## Read the correct experiment and metric

**Final proposed configuration:** segmentation + FPFCS + KD, with EC and decoder deep supervision disabled. EC remains a separate ablation.

**Matched comparison:** exactly 100 epochs, seeds 42, 43, and 44; shared KD teacher and common hyperparameters; only the three FPFCS loss weights differ. Full FPFCS: Dice 87.35 +/- 0.02%, IoU 79.81 +/- 0.02%, BF1 45.81 +/- 0.64%. No FPFCS: Dice 87.14 +/- 0.13%, IoU 79.49 +/- 0.20%, BF1 45.25 +/- 0.93%. Spread is sample SD.

**Primary protocol:** at most 200 epochs, early-stopping patience 40, highest validation-Dice checkpoint. EC-free PicoSemaNet: Dice 87.39 +/- 0.09%, IoU 79.88 +/- 0.13%, Euclidean BF1 46.28 +/- 0.71%. Exact run identities are in `evidence/current_configuration_20261009/configuration_mapping.json`.

**BF1:** final prediction/reference masks; 3 x 3 morphological gradient; bidirectional, many-to-many matching with a two-pixel Euclidean tolerance in the 320 x 320 evaluation space. The new release helper explicitly uses the archived Euclidean implementation. Historical square-tolerance BF1 is retained for provenance and must not be substituted for the manuscript's Euclidean BF1.

Historical labels and the older paper title inside `evidence/` are archival text. In particular, the old BF1 manifest's group `proposed` denotes the former EC-containing variant; `no_ec` denotes the current primary EC-free model. Use the current configuration mapping above.

## Data, environments, and limits

The original ISIC images/masks are not redistributed. Obtain them from the official ISIC source and preserve the exact split. No patient-level independence is inferred from this image split. See `REPRODUCE.md`.

Original GPU scores and subsequent CPU metric replays remain distinct. CPU replay in a different software/hardware environment is not a promise of bit-identical GPU results. No new training or replacement of manuscript results was performed for this release.

## Rights and citation

Original software is MIT-licensed; author-created records, figures and checkpoints are CC BY 4.0. See `RIGHTS.md` for exact scope and third-party notices. The release DOI must be registered by publication on Zenodo; an unpublished reserved DOI is not a working public download.
