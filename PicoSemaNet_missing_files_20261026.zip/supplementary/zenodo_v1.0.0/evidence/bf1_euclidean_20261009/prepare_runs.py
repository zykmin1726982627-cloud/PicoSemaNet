"""Select the existing paper checkpoints without modifying archived evidence."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "baseline_source"

def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()

def main():
    groups = {}
    summary = json.loads((SOURCE / "formal_paper_multiseed_v1/multiseed_summary.json").read_text())
    for name, original in [("proposed", "best_under0005m_no_deep"),
                           ("context", "main_3m_fullpath"),
                           ("micro", "main_under001m_fullpath"),
                           ("deep_supervision", "main_under0005m_fullpath")]:
        groups[name] = [str(Path(row["path"]).parent).replace("\\", "/") for row in summary[original]["runs"]]
    p = "formal_paper_seed42_v1/"
    n = "formal_paper_ablation_nds_v1/"
    q = "formal_paper_ablation_priority_v1/"
    s = "formal_paper_ablation_supplement_v1/"
    b = "formal_paper_requested_baselines_v1/"
    l = "formal_paper_last30h_v1/"
    groups.update({
        "no_fpfcs": [n+"m2_no_fullpath_seed42", s+"s2_no_fullpath_seed43", q+"m2_no_fullpath_seed44"],
        "shallow": [n+"m3_shallow_semantic_seed42", q+"m3_shallow_semantic_seed43", q+"m3_shallow_semantic_seed44"],
        "projection": [s+"s4_learned_head_fullpath_seed42", b+"projection_head_seed43", b+"projection_head_seed44"],
        "no_boundary": [n+"m4_no_boundary_seed42", l+"m4_no_boundary_seed43", l+"m4_no_boundary_seed44"],
        "no_texture": [n+"m5_no_texture_seed42", l+"m5_no_texture_seed43", l+"m5_no_texture_seed44"],
        "no_distance": [n+"m6_no_sdf_seed42", l+"m6_no_sdf_seed43", l+"m6_no_sdf_seed44"],
        "no_kd": [s+"s3a_no_distill_seed42", l+"no_distill_seed43", l+"no_distill_seed44"],
        "no_ec": [s+"s3b_no_edge_seed42", l+"no_edge_seed43", l+"no_edge_seed44"],
        "unet": [b+"original_unet_seed42", l+"original_unet_seed43", l+"original_unet_seed44"],
        "tiny_unet": [b+"tiny_unet_5k_seed42", l+"tiny_unet_5k_seed43", l+"tiny_unet_5k_seed44"],
        "seg_only": [p+"ablation_a0_seg_only_seed42"],
        "seg_kd": [p+"ablation_a1_distill_only_seed42"],
        "encoder_only": [s+"s5_encoder_semantic_seed42"],
        "full_100": [s+"s1_budget_matched_fullpath_seed42"],
        "teacher": [p+"teacher_performance_context_seed42"],
    })
    archives = [Path.home()/"Downloads/UNET_all_experiment_data_through_20260922.zip",
                Path.home()/"Downloads/UNET_last30h_new_results_20260924.zip"]
    runs = []
    for archive in archives:
        with zipfile.ZipFile(archive) as z:
            entries = {"/".join(name.split("/")[1:-1]): name for name in z.namelist() if name.endswith("/best.pt")}
            for group, paths in groups.items():
                for run in paths:
                    if run not in entries:
                        continue
                    member = entries[run]
                    destination = ROOT / "checkpoints" / run / "best.pt"
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    info = z.getinfo(member)
                    if not destination.exists():
                        with z.open(member) as src, destination.open("wb") as dst:
                            for chunk in iter(lambda: src.read(1024*1024), b""):
                                dst.write(chunk)
                    assert destination.stat().st_size == info.file_size
                    config = json.loads((SOURCE/run/"config.json").read_text())
                    original_metrics = json.loads((SOURCE/run/"test_metrics.json").read_text())
                    runs.append({"group": group, "run": run, "checkpoint": str(destination),
                                 "checkpoint_sha256": sha256(destination), "archive": str(archive),
                                 "archive_member": member, "seed": config["seed"],
                                 "model": config["model"], "config": config,
                                 "original_metrics": original_metrics})
    expected = [run for group in groups.values() for run in group]
    assert sorted(expected) == sorted(row["run"] for row in runs), "Missing or duplicated checkpoint"
    # Evaluate the small models first, then the larger controls.
    priority = {"proposed": 0, "no_fpfcs": 1, "no_ec": 2, "context": 10, "unet": 11, "teacher": 12}
    runs.sort(key=lambda row: (priority.get(row["group"], 5), row["group"], row["seed"]))
    manifest = {"groups": groups, "runs": runs,
                "split_sha256": sha256(SOURCE/"data/ISIC2018/paper_split_70_10_20_seed20260912.json")}
    (ROOT/"run_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"READY: {len(runs)} archived checkpoints, {len(groups)} table groups", flush=True)

if __name__ == "__main__": main()
