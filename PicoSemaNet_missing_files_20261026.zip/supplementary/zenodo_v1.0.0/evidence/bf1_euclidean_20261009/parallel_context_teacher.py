"""Evaluate disjoint future controls with the same four-thread CPU protocol."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent

def main():
    separate = ROOT/"parallel_context_teacher_results"
    log_path = ROOT/"parallel_context_teacher.log"
    args = [sys.executable, str(ROOT/"reevaluate.py"), "--threads", "4", "--batch-size", "8",
            "--groups", "context", "teacher", "--output-dir", str(separate)]
    manifest = json.loads((ROOT/"run_manifest.json").read_text())
    selected = [r for r in manifest["runs"] if r["group"] in ["context", "teacher"]]
    copied = set()
    with log_path.open("w", encoding="utf-8") as log:
        process = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT)
        while True:
            for row in selected:
                src = separate/row["run"]
                if row["run"] in copied or not (src/"metrics.json").exists():
                    continue
                result = json.loads((src/"metrics.json").read_text())
                assert result["num_images"]==520 and result["checkpoint_sha256"]==row["checkpoint_sha256"]
                assert result["provenance"]["threads"]==4 and result["provenance"]["batch_size"]==8
                assert result["provenance"]["script_sha256"]==hashlib.sha256((ROOT/"reevaluate.py").read_bytes()).hexdigest()
                destination = ROOT/"results"/row["run"]
                if destination.exists():
                    copied.add(row["run"])
                    print("PRIMARY_ALREADY_STARTED "+row["run"], flush=True)
                    continue
                temporary = destination.with_name(destination.name+".parallel-ready")
                temporary.parent.mkdir(parents=True, exist_ok=True)
                shutil.copytree(src,temporary)
                try:
                    temporary.rename(destination)
                except FileExistsError:
                    print("PRIMARY_ALREADY_STARTED "+row["run"], flush=True)
                else:
                    print("IMPORTED "+row["run"], flush=True)
                copied.add(row["run"])
            code = process.poll()
            if code is not None:
                if code != 0:
                    raise RuntimeError(f"Control replay failed; see {log_path}")
                assert len(copied)==len(selected)
                break
            time.sleep(3)
    print("PARALLEL_CONTROLS_FINISHED", flush=True)

if __name__=="__main__": main()
