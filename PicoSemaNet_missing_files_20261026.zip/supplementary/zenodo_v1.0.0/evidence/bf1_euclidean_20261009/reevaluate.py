"""CPU replay of archived checkpoints with old and Euclidean BF1 side by side."""
from pathlib import Path, PurePosixPath, PureWindowsPath
import argparse
import csv
import hashlib
import json
import platform
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
sys.path.insert(0, str(WORKSPACE / ".figure_torch"))
sys.path.insert(0, str(ROOT / "baseline_source"))
import numpy as np
import PIL
from PIL import Image
import torch
from src.models import build_model
from src.metrics import dice_score, iou_score, boundary_f1_score, accuracy_score
from bf1_euclidean import euclidean_boundary_f1_score

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save_json(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temporary.replace(path)

def preload(ids, pilot, data):
    examples = WORKSPACE / "IJCV_language_polished_submission_20260924/qualitative_comparison_20260927/assets"
    x = torch.empty((len(ids), 3, 320, 320), dtype=torch.float32)
    y = torch.empty((len(ids), 1, 320, 320), dtype=torch.bool)
    for index, image_id in enumerate(ids):
        ip = examples/f"{image_id}.jpg" if pilot else data/"images"/f"{image_id}.jpg"
        mp = examples/f"{image_id}_segmentation.png" if pilot else data/"masks"/f"{image_id}_segmentation.png"
        with Image.open(ip) as f:
            original_size = f.size
            image = f.convert("RGB").resize((320, 320), Image.Resampling.BILINEAR)
        with Image.open(mp) as f:
            assert f.size == original_size, image_id
            mask = f.convert("L").resize((320, 320), Image.Resampling.NEAREST)
        tensor = torch.from_numpy(np.asarray(image, dtype=np.float32)/255.0).permute(2, 0, 1)
        x[index] = (tensor - 0.5)/0.5
        y[index, 0] = torch.from_numpy(np.asarray(mask)>0)
        if (index+1) % 100 == 0:
            print(f"PREPROCESSED {index+1}/{len(ids)}", flush=True)
    return x, y

def load(row, checkpoint_root=None):
    checkpoint_path = checkpoint_root/row["run"]/"best.pt" if checkpoint_root else Path(row["checkpoint"])
    assert sha(checkpoint_path) == row["checkpoint_sha256"], row["run"]
    with torch.serialization.safe_globals([(PurePosixPath, "pathlib.PosixPath"), torch.torch_version.TorchVersion]):
        checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=True)
    config = checkpoint["config"]
    model_name = checkpoint.get("model_name", config["model"])
    assert model_name == row["model"]
    assert int(checkpoint.get("seed", config["seed"])) == row["seed"]
    expected_epoch = row["original_metrics"].get("checkpoint_epoch")
    if expected_epoch is not None:
        assert checkpoint["epoch"] == expected_epoch, (row["run"], checkpoint["epoch"], expected_epoch)
    model = build_model(model_name, in_channels=int(config.get("in_channels", 3)),
                        out_channels=int(config.get("out_channels", 1)),
                        base_channels=int(config["base_channels"]))
    model.load_state_dict(checkpoint["model_state_dict"], strict=True)
    model.eval()
    return model, {"epoch": checkpoint.get("epoch"), "best_val_dice": checkpoint.get("best_val_dice")}

def aggregate(manifest, output, provenance):
    completed = []
    for row in manifest["runs"]:
        path = output/row["run"]/"metrics.json"
        if path.exists():
            completed.append(json.loads(path.read_text()))
    groups = {}
    for group, paths in manifest["groups"].items():
        items = [r for r in completed if r["run"] in paths]
        if len(items) != len(paths):
            continue
        groups[group] = {"n": len(items), "seeds": [r["seed"] for r in items],
                         "runs": [r["run"] for r in items]}
        for metric in ["dice", "iou", "accuracy", "bf1_square", "bf1_euclidean"]:
            values = [r[metric] for r in items]
            groups[group][metric+"_mean"] = statistics.mean(values)
            groups[group][metric+"_std"] = statistics.stdev(values) if len(values)>1 else None
    save_json(output/"summary.json", {"provenance": provenance, "completed": len(completed),
              "expected": len(manifest["runs"]), "groups": groups, "runs": completed})

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pilot", action="store_true")
    parser.add_argument("--groups", nargs="*")
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--dataset-root", type=Path, default=Path("F:/Datasets/ISIC2018"))
    parser.add_argument("--checkpoint-root", type=Path)
    parser.add_argument("--output-dir", type=Path)
    args = parser.parse_args()
    torch.set_num_threads(args.threads)
    manifest = json.loads((ROOT/"run_manifest.json").read_text())
    split = ROOT/"baseline_source/data/ISIC2018/paper_split_70_10_20_seed20260912.json"
    ids = json.loads(split.read_text())["test"]
    assert len(ids) == 520 and len(set(ids)) == 520
    if args.pilot: ids = ids[:4]
    output = args.output_dir or ROOT/("pilot_results" if args.pilot else "results")
    output.mkdir(exist_ok=True)
    provenance = {"python": sys.version, "torch": str(torch.__version__), "numpy": np.__version__,
                  "pillow": PIL.__version__, "platform": platform.platform(), "device": "cpu",
                  "dtype": "float32", "threads": args.threads, "batch_size": args.batch_size,
                  "image_size": [320, 320], "threshold": 0.5, "boundary_kernel": [3, 3],
                  "tolerance": 2, "distance": "Euclidean", "split_sha256": sha(split),
                  "num_images": len(ids), "pilot": args.pilot,
                  "script_sha256": sha(Path(__file__)),
                  "metric_sha256": sha(ROOT/"bf1_euclidean.py"),
                  "source_models_sha256": sha(ROOT/"baseline_source/src/models.py"),
                  "source_metrics_sha256": sha(ROOT/"baseline_source/src/metrics.py")}
    if not args.pilot:
        data_manifest = args.dataset_root/"test_download_manifest.json"
        data_record = json.loads(data_manifest.read_text())
        assert not data_record["failures"] and len(data_record["records"]) == 1040
        assert data_record["test_count"] == 520
        assert data_record["split_sha256"] == provenance["split_sha256"]
        expected = {("images", f"{i}.jpg") for i in ids} | {("masks", f"{i}_segmentation.png") for i in ids}
        observed = set()
        for record in data_record["records"]:
            recorded_path = PureWindowsPath(record["path"]) if "\\" in record["path"] else Path(record["path"])
            pair = (recorded_path.parent.name, recorded_path.name)
            observed.add(pair)
            assert sha(args.dataset_root/pair[0]/pair[1]) == record["sha256"], pair
        assert observed == expected
        provenance["data_manifest_sha256"] = sha(data_manifest)
        print("DATA_VERIFIED: 520 original image-mask pairs and fixed split hashes", flush=True)
    save_json(output/"provenance.json", provenance)
    x, y = preload(ids, args.pilot, args.dataset_root)
    selected = [r for r in manifest["runs"] if not args.groups or r["group"] in args.groups]
    if args.pilot:
        selected = [r for r in selected if r["seed"] == 42]
    with torch.inference_mode():
        for run_index, row in enumerate(selected):
            directory = output/row["run"]
            directory.mkdir(parents=True, exist_ok=True)
            if (directory/"metrics.json").exists():
                previous = json.loads((directory/"metrics.json").read_text())
                assert previous["checkpoint_sha256"] == row["checkpoint_sha256"]
                for key in ["script_sha256", "metric_sha256", "source_models_sha256", "source_metrics_sha256", "split_sha256", "num_images"]:
                    assert previous["provenance"][key] == provenance[key], (row["run"], key)
                print(f"RESUME {row['run']}", flush=True)
                continue
            model, checkpoint_meta = load(row, args.checkpoint_root)
            print(f"START {run_index+1}/{len(selected)} {row['run']}", flush=True)
            records = []
            packed = np.empty((len(ids), 320, 40), dtype=np.uint8)
            start = time.perf_counter()
            for offset in range(0, len(ids), args.batch_size):
                end = min(offset+args.batch_size, len(ids))
                logits = model(x[offset:end], return_aux=False)["seg_logits"]
                pred = logits.sigmoid() >= 0.5
                target = y[offset:end]
                metrics = {
                    "dice": dice_score(pred, target, reduction="none").tolist(),
                    "iou": iou_score(pred, target, reduction="none").tolist(),
                    "accuracy": accuracy_score(pred, target, reduction="none").tolist(),
                    "bf1_square": boundary_f1_score(pred, target, reduction="none").tolist(),
                    "bf1_euclidean": euclidean_boundary_f1_score(pred, target, reduction="none").tolist(),
                }
                assert all(e <= s+1e-6 for e,s in zip(metrics["bf1_euclidean"], metrics["bf1_square"]))
                for index, image_id in enumerate(ids[offset:end]):
                    records.append({"id": image_id, **{k:v[index] for k,v in metrics.items()}})
                packed[offset:end] = np.packbits(pred[:,0].numpy(), axis=-1)
                if end % 80 == 0 or end == len(ids):
                    progress = {"run": row["run"], "completed_images": end, "total_images": len(ids),
                                "seconds": round(time.perf_counter()-start, 1),
                                "run_index": run_index+1, "total_runs": len(selected)}
                    save_json(output/"progress.json", progress)
                    print(json.dumps(progress), flush=True)
            with (directory/"per_image_metrics.csv").open("w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=list(records[0]))
                writer.writeheader(); writer.writerows(records)
            np.savez_compressed(directory/"predicted_masks.npz", ids=np.array(ids), masks_packbits=packed,
                                shape=np.array([len(ids), 320, 320]), bitorder="big")
            result = {"run": row["run"], "group": row["group"], "seed": row["seed"],
                      "checkpoint_sha256": row["checkpoint_sha256"], **checkpoint_meta,
                      "num_images": len(ids), "seconds": time.perf_counter()-start,
                      "original_metrics": row["original_metrics"], "provenance": provenance}
            for metric in metrics:
                result[metric] = statistics.mean(r[metric] for r in records)
            result["replay_minus_original"] = {key:result[newkey]-row["original_metrics"][key]
                    for key,newkey in [("dice","dice"),("iou","iou"),("accuracy","accuracy"),("bf1","bf1_square")]
                    if key in row["original_metrics"]}
            save_json(directory/"metrics.json", result)
            aggregate(manifest, output, provenance)
            print("DONE " + json.dumps({k:result[k] for k in ["run","dice","bf1_square","bf1_euclidean","seconds"]}), flush=True)
            del model
    aggregate(manifest, output, provenance)

if __name__ == "__main__": main()
