# BF1 修改与复算记录（2026-10-09）

本次完成教授第三点要求：把 BF1 改为两像素欧氏距离匹配，补齐可复现定义，并重算现有论文表格。使用已有最佳验证 Dice 检查点，没有重新训练模型。

## 输入与范围

- 数据：ISIC 官方训练数据中论文固定的 520 个内部测试图像–标注对，保存于 `F:\Datasets\ISIC2018`，共 2,317,094,137 字节。不是完整训练数据集或官方隐藏测试集。
- 数据来源：https://challenge.isic-archive.com/data/ 。每个文件已核对官方 ZIP 的长度、CRC32，并记录、复核 SHA-256。四对已有示例也逐字节相同。
- 固定划分 SHA-256：`ff709315d972d602969d1da5815170abade7d0c08fa0d8c09264968a80df5228`。
- 权重：47 份已有 best.pt，覆盖 19 组配置、论文 26 个 BF1 表格单元。加载时检查权重 SHA-256、模型、种子、检查点 epoch，并严格恢复模型参数。

## 本地原稿修改

- 3×3 形态学梯度分别提取预测和参考边界，说明图像边缘只使用图内邻域。
- 容差是 320×320 评价空间中的两像素欧氏距离；预测和参考边界各自使用半径 2 的离散圆盘膨胀。
- 给出精确的 precision、recall 和 BF1 公式，逐像素一次计数、允许多对多匹配，并定义空边界的结果。
- 更新三张表的全部 26 个 BF1 值，以及摘要和相关结果句子。参数、MACs、验证 Dice、原始 GPU Dice/IoU 保持原有数据来源。
- 说明 BF1 为 CPU/PyTorch 2.14.0 的 FP32 复算；原始 GPU/PyTorch 2.11.0 的评价记录保留在补充材料。

## 主要结果

- 当前原稿 Full FPFCS（含 EC）：45.35 ± 1.33%。
- 当前原稿 No FPFCS（Seg+KD+EC）：45.45 ± 0.95%。
- 无 EC 的 FPFCS 配置：46.28 ± 0.71%。
- 新欧氏 BF1 下，当前 Full FPFCS 的均值没有高于 No FPFCS；结果文字已避免继续声称 BF1 优势。这里尚未把无 EC 配置改为论文 Proposed，也没有完成教授另行要求的 100 epochs × 3 seeds 新实验。

## 验证

- **通过**：全部 47×520=24,440 条逐图记录完整，图像顺序与固定列表相同。
- **通过**：逐图均值、三种子均值及样本标准差重新聚合一致。
- **通过**：全部逐图欧氏 BF1 不超过同一次 CPU 预测的方形 BF1。
- **通过**：独立 NumPy 实现核对 seed-42 Full FPFCS 的全部 520 张预测；最大绝对误差 `7.96e-08`。
- **记录差异**：CPU 复算与原始 GPU 结果并不完全相同；下列差异为各运行测试均值的最大绝对差，单位为百分点，原因未被实验证实。

| 指标 | 最大 CPU–原始 GPU 差异（百分点） |
|---|---:|
| dice | 0.178347 |
| iou | 0.235367 |
| accuracy | 0.113470 |
| bf1 | 0.465019 |

## 表格数值对应

旧值是原稿中的 GPU 方形容差 BF1；新值是同一检查点的 CPU 欧氏容差 BF1。评价规则和运行环境均已明确记录。

| 表 | 行 | 原稿 BF1 | 新 BF1 |
|---|---|---|---|
| tab:results | Context Teacher$^\dagger$ | `56.69` | `50.72` |
| tab:results | U-Net (Seg) | `$51.71\!\pm\!0.37$` | `$46.01\!\pm\!0.31$` |
| tab:results | ContextUNet-3M | `$55.99\!\pm\!0.44$` | `$49.94\!\pm\!0.37$` |
| tab:results | MicroSemaNet | `$52.24\!\pm\!0.37$` | `$46.40\!\pm\!0.41$` |
| tab:results | Matched-size U-Net (Seg) | `$48.71\!\pm\!1.93$` | `$43.12\!\pm\!1.87$` |
| tab:results | \textbf{PicoSemaNet} | `$51.13\!\pm\!1.27$` | `$45.35\!\pm\!1.33$` |
| tab:pico-ablation | Seg only | `48.40` | `42.76` |
| tab:pico-ablation | Seg + KD | `51.55` | `45.75` |
| tab:pico-ablation | No FPFCS (Seg+KD+EC) | `51.82` | `46.42` |
| tab:pico-ablation | Shallow FCS ($E_1$--$E_3$) | `50.57` | `44.85` |
| tab:pico-ablation | Encoder-only FCS ($E_1$--$E_4,B$) | `50.80` | `45.27` |
| tab:pico-ablation | Learned $1\times1$ projection | `51.66` | `45.84` |
| tab:pico-ablation | PicoSemaNet w/o KD | `50.28` | `44.78` |
| tab:pico-ablation | PicoSemaNet w/o EC | `52.83` | `47.07` |
| tab:pico-ablation | PicoSemaNet + DS (not used) | `49.49` | `43.60` |
| tab:pico-ablation | PicoSemaNet | `52.05` | `46.34` |
| tab:ablation | No FPFCS (Seg+KD+EC) | `$51.14\!\pm\!0.74$` | `$45.45\!\pm\!0.95$` |
| tab:ablation | Shallow FCS ($E_1$--$E_3$) | `$50.94\!\pm\!0.47$` | `$45.11\!\pm\!0.54$` |
| tab:ablation | Full-path FPFCS | `$51.13\!\pm\!1.27$` | `$45.35\!\pm\!1.33$` |
| tab:ablation | Learned $1\times1$ projection | `$50.99\!\pm\!0.60$` | `$45.10\!\pm\!0.65$` |
| tab:ablation | Full-path FPFCS (100 epochs)$^{\dagger\ddagger}$ | `51.86` | `46.16` |
| tab:ablation | FPFCS w/o Boundary$^\ddagger$ | `$50.70\!\pm\!0.21$` | `$44.88\!\pm\!0.13$` |
| tab:ablation | FPFCS w/o Texture$^\ddagger$ | `$51.11\!\pm\!0.01$` | `$45.24\!\pm\!0.23$` |
| tab:ablation | FPFCS w/o Distance$^\ddagger$ | `$51.27\!\pm\!0.18$` | `$45.53\!\pm\!0.15$` |
| tab:ablation | FPFCS w/o KD | `$50.57\!\pm\!0.33$` | `$44.96\!\pm\!0.29$` |
| tab:ablation | FPFCS w/o EC | `$52.05\!\pm\!0.67$` | `$46.28\!\pm\!0.71$` |

## 交付与当前边界

- `sn-article.tex`：在原有编辑器中原位修改。
- `results/`：所有复算输出；`verification.json`：独立检查。
- `Online_Resource_1_reproducibility.zip`：保留历史结果并增加欧氏 BF1 的代码、逐图指标、来源和哈希。旧 ZIP 和修改前原稿保留在本目录。
- 只更新本地文件；Overleaf 在线项目未上传本次更改。
- 内置 LaTeX 编译器未成功：`Unable to find standard directories for platform`。这是编译环境诊断；原编辑器保持打开，源文件已保存，当前 PDF 编译未验证。详见 `compile_diagnostics.json`。
