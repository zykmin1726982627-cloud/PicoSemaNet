"""Replace only BF1 numbers after all 47 checkpoint replays finish."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent

def main():
    summary = json.loads((ROOT/"results/summary.json").read_text())
    assert summary["completed"] == summary["expected"] == 47
    groups = summary["groups"]
    runs = {r["run"]: r for r in summary["runs"]}
    def value(group, single=False):
        data = groups[group]
        if single:
            seed42 = next(runs[r] for r in data["runs"] if runs[r]["seed"] == 42)
            return f"{100*seed42['bf1_euclidean']:.2f}"
        mean = 100*data["bf1_euclidean_mean"]
        sd = data["bf1_euclidean_std"]
        return f"${mean:.2f}\\!\\pm\\!{100*sd:.2f}$" if sd is not None else f"{mean:.2f}"
    tables = {
        "tab:results": {
            "Context Teacher": "teacher", "U-Net (Seg)": "unet", "ContextUNet-3M": "context",
            "MicroSemaNet": "micro", "Matched-size U-Net": "tiny_unet", "\\textbf{PicoSemaNet}": "proposed"},
        "tab:pico-ablation": {
            "Seg only": "seg_only", "Seg + KD": "seg_kd", "No FPFCS": "no_fpfcs", "Shallow FCS": "shallow",
            "Encoder-only FCS": "encoder_only", "Learned $1\\times1$": "projection", "PicoSemaNet w/o KD": "no_kd",
            "PicoSemaNet w/o EC": "no_ec", "PicoSemaNet + DS": "deep_supervision", "PicoSemaNet &": "proposed"},
        "tab:ablation": {
            "No FPFCS": "no_fpfcs", "Shallow FCS": "shallow", "Full-path FPFCS &": "proposed",
            "Learned $1\\times1$": "projection", "Full-path FPFCS (100 epochs)": "full_100",
            "FPFCS w/o Boundary": "no_boundary", "FPFCS w/o Texture": "no_texture", "FPFCS w/o Distance": "no_distance",
            "FPFCS w/o KD": "no_kd", "FPFCS w/o EC": "no_ec"},
    }
    manuscript = ROOT.parent/"sn-article.tex"
    source = manuscript.read_text(encoding="utf-8")
    lines = source.splitlines(keepends=True)
    active = None
    changed = []
    for index, line in enumerate(lines):
        for label in tables:
            if "\\label{"+label+"}" in line:
                active = label
        if "\\end{table*}" in line:
            active = None
        if active and "&" in line:
            for prefix, group in tables[active].items():
                if line.strip().startswith(prefix):
                    before, old = line.rsplit("&", 1)
                    new = value(group, active=="tab:pico-ablation")
                    lines[index] = before+"& "+new+" \\\\\n"
                    changed.append({"table": active, "row": line.split("&")[0].strip(),
                                    "old_bf1": old.strip().rstrip("\\").strip(), "new_bf1": new})
                    break
    assert len(changed) == 26, changed
    revised = "".join(lines)
    mean, sd = (100*groups["proposed"]["bf1_euclidean_"+key] for key in ["mean", "std"])
    revised = revised.replace("$51.13\\pm1.27$\\%", f"${mean:.2f}\\pm{sd:.2f}$\\%")
    p = next(runs[r] for r in groups["proposed"]["runs"] if runs[r]["seed"]==42)
    n = next(runs[r] for r in groups["no_fpfcs"]["runs"] if runs[r]["seed"]==42)
    delta = 100*(p["bf1_euclidean"]-n["bf1_euclidean"])
    revised = revised.replace(
        "At seed 42, full-path FPFCS exceeds Seg+KD+EC by 0.38 Dice, 0.36 IoU, and\n"
        "0.23 BF1 points; it exceeds shallow FCS by 1.01 Dice points.",
        "At seed 42, full-path FPFCS exceeds Seg+KD+EC by 0.38 Dice and 0.36 IoU\n"
        f"points. Euclidean BF1 is {100*p['bf1_euclidean']:.2f}\\% for full-path FPFCS and\n"
        f"{100*n['bf1_euclidean']:.2f}\\% for no FPFCS. Full-path FPFCS exceeds shallow FCS\n"
        "by 1.01 Dice points.")
    ec_mean, ec_sd = (100*groups["no_ec"]["bf1_euclidean_"+key] for key in ["mean", "std"])
    revised = revised.replace("$52.05\\pm0.67$\\% BF1", f"${ec_mean:.2f}\\pm{ec_sd:.2f}$\\% BF1")
    if ec_mean <= mean:
        revised = revised.replace("proposed configuration on both metrics.", "proposed configuration on Dice.")
    revised = revised.replace("Training and full-test evaluation ran on an RTX A5000 with\nPyTorch 2.11.0+cu128 and CUDA 12.8.",
        "Training and the original full-test evaluation ran on an RTX A5000 with\nPyTorch 2.11.0+cu128 and CUDA 12.8. The BF1 values reported here were\nrecomputed from the same selected checkpoints on CPU with PyTorch 2.14.0\nin FP32, using the Euclidean matching rule below. Dice and IoU retain the\noriginal GPU evaluation values. Online Resource~1 records both the original\nsquare-tolerance BF1 and this Euclidean reevaluation.")
    revised = revised.replace("the tables retain the original GPU evaluation results.",
        "the tables retain the original GPU Dice and IoU values and use the\nCPU reevaluation for Euclidean BF1.")
    revised = revised.replace("Matching is not one-to-one.", "Matching allows many-to-many correspondence.")
    save_path = ROOT/"bf1_table_changes.json"
    save_path.write_text(json.dumps({"changes": changed, "seed42_bf1_gain": delta,
        "proposed_bf1_mean": mean, "proposed_bf1_sd": sd}, indent=2), encoding="utf-8")
    manuscript.write_text(revised, encoding="utf-8")
    print(f"UPDATED {len(changed)} BF1 table cells and corresponding prose")

if __name__ == "__main__": main()
