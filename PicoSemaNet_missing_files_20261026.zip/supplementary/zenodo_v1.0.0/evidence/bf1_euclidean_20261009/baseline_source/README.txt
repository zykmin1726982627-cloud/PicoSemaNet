Online Resource 1: Reproducibility files

Article: Full-Path Fixed-Channel Supervision for Extremely Lightweight Skin Lesion Segmentation

This archive contains training and evaluation code, the fixed split identifiers,
per-run configurations and test metrics, training logs for the 14 runs added on
2026-09-24, three-seed result summaries, per-image bootstrap inputs, and
bootstrap outputs. The new runs complete seeds 43 and 44 for the conventional
U-Net and equal-parameter U-Net baselines and for the no-KD, no-EC, no-boundary,
no-texture, and no-distance controls. Their seed-42 artifacts were already in
the earlier archive and remain here.

The new runs came from UNET_last30h_new_results_20260924.zip
SHA-256: 5688ca092700b9687bd8652dee1dad41e4c87332293258b67309778e4a6f2d38

The ISIC 2018 images and masks and model checkpoints are not redistributed.
MANIFEST.sha256 verifies every other file in this archive.
Verification update 2026-09-28: qualitative_replay/ contains figure provenance and CPU per-image measurements, kept separate from the original GPU records. verification_20260928/ contains a forward-hook parameter/MAC recount and script.
