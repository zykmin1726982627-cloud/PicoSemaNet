"""Summarize completed formal seed-42--44 runs with sample statistics."""

from __future__ import annotations

import csv
import json
import statistics
from pathlib import Path
from typing import Any

from src.utils import save_json


ROOT42 = Path("formal_paper_seed42_v1")
ROOT_MULTI = Path("formal_paper_multiseed_v1")
VARIANTS = {
    "main_3m_fullpath": "main_3m_fullpath_seed{seed}",
    "main_under001m_fullpath": "main_under001m_fullpath_seed{seed}",
    "main_under0005m_fullpath": "main_under0005m_fullpath_seed{seed}",
    "best_under0005m_no_deep": "ablation_a7_no_deep_seed{seed}",
}
METRICS = ("dice", "iou", "accuracy", "bf1")


def result_path(template: str, seed: int) -> Path:
    root = ROOT42 if seed == 42 else ROOT_MULTI
    return root / template.format(seed=seed) / "test_metrics.json"


def summarize() -> dict[str, Any]:
    result: dict[str, Any] = {}
    rows: list[dict[str, Any]] = []
    for variant, template in VARIANTS.items():
        runs: list[dict[str, Any]] = []
        for seed in (42, 43, 44):
            path = result_path(template, seed)
            if not path.is_file():
                continue
            with path.open(encoding="utf-8") as handle:
                payload = json.load(handle)
            run = {"seed": seed, "path": str(path)}
            run.update({name: float(payload[name]) for name in METRICS})
            run["checkpoint_epoch"] = int(payload["checkpoint_epoch"])
            run["inference_parameters"] = int(payload["inference_parameters"])
            runs.append(run)
            rows.append({"variant": variant, **run})
        aggregate: dict[str, Any] = {
            "n": len(runs),
            "seeds": [run["seed"] for run in runs],
            "runs": runs,
        }
        for metric in METRICS:
            values = [run[metric] for run in runs]
            aggregate[f"{metric}_mean"] = statistics.fmean(values) if values else None
            aggregate[f"{metric}_std"] = (
                statistics.stdev(values) if len(values) >= 2 else None
            )
        result[variant] = aggregate
    ROOT_MULTI.mkdir(parents=True, exist_ok=True)
    save_json(result, ROOT_MULTI / "multiseed_summary.json")
    with (ROOT_MULTI / "multiseed_runs.csv").open(
        "w", encoding="utf-8", newline=""
    ) as handle:
        fields = (
            "variant",
            "seed",
            *METRICS,
            "checkpoint_epoch",
            "inference_parameters",
            "path",
        )
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    return result


if __name__ == "__main__":
    summary = summarize()
    for name, values in summary.items():
        print(
            f"{name}: n={values['n']} seeds={values['seeds']} "
            f"dice={values['dice_mean']}+-{values['dice_std']}"
        )
