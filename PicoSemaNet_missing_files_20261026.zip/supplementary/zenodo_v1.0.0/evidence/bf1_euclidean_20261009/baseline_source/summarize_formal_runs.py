"""Collect completed formal-paper runs into one stable CSV/JSON table."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


FIELDS = (
    "run",
    "model",
    "seed",
    "epochs_completed",
    "best_epoch",
    "best_val_dice",
    "dice",
    "iou",
    "accuracy",
    "bf1",
    "inference_parameters",
    "trainable_parameters",
    "inference_ms_per_image",
)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    args = parser.parse_args()
    rows = []
    for path in sorted(args.root.glob("*/test_metrics.json")):
        metrics = json.loads(path.read_text(encoding="utf-8"))
        config_path = path.parent / "config.json"
        config = (
            json.loads(config_path.read_text(encoding="utf-8"))
            if config_path.is_file()
            else {}
        )
        merged = config | metrics
        rows.append({"run": path.parent.name, **{key: merged.get(key) for key in FIELDS[1:]}})
    csv_path = args.root / "formal_results.csv"
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    (args.root / "formal_results.json").write_text(
        json.dumps(rows, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(f"wrote {len(rows)} completed runs to {csv_path}")


if __name__ == "__main__":
    main()
