from pathlib import Path
import sys,json,math
import torch
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root.parent))
from src.models import build_model
from src.utils import count_inference_parameters
torch.set_num_threads(2)
runs=['formal_paper_seed42_v1/ablation_a7_no_deep_seed42','formal_paper_seed42_v1/main_under001m_fullpath_seed42','formal_paper_seed42_v1/main_3m_fullpath_seed42','formal_paper_seed42_v1/teacher_performance_context_seed42']
records=[]
for run in runs:
 cfg=json.loads((root.parent/run/'config.json').read_text())
 model=build_model(cfg['model'],base_channels=cfg['base_channels']).eval()
 ops=[]
 def hook(m,inputs,output):
  if isinstance(m,(torch.nn.Conv1d,torch.nn.Conv2d)):
   ops.append(int(output.numel()*(m.in_channels//m.groups)*math.prod(m.kernel_size)))
  elif isinstance(m,torch.nn.ConvTranspose2d):ops.append(int(inputs[0].numel()*(m.out_channels//m.groups)*math.prod(m.kernel_size)))
  elif isinstance(m,torch.nn.Linear):ops.append(int(output.numel()*m.in_features))
 handles=[m.register_forward_hook(hook) for m in model.modules() if isinstance(m,(torch.nn.Conv1d,torch.nn.Conv2d,torch.nn.ConvTranspose2d,torch.nn.Linear))]
 with torch.inference_mode():model(torch.zeros(1,3,320,320))
 for h in handles:h.remove()
 records.append(dict(run=run,model=cfg['model'],training_parameters=sum(p.numel() for p in model.parameters()),inference_parameters=count_inference_parameters(model),macs=sum(ops)))
 print(records[-1],flush=True)
(root/'model_count_checks.json').write_text(json.dumps(records,indent=2))
