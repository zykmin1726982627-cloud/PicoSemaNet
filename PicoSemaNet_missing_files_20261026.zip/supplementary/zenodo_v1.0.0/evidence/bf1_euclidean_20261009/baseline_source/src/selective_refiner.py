"""A lightweight, spatially gated residual refiner around a frozen segmenter."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import torch
from torch import Tensor, nn


class ConvBlock(nn.Sequential):
    def __init__(self, in_channels: int, out_channels: int) -> None:
        groups = min(8, out_channels)
        super().__init__(
            nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False),
            nn.GroupNorm(groups, out_channels),
            nn.GELU(),
            nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
            nn.GroupNorm(groups, out_channels),
            nn.GELU(),
        )


class SelectiveResidualRefiner(nn.Module):
    """Keep the baseline fixed and add a gated, zero-initialized logit residual."""

    def __init__(self, baseline: nn.Module, width: int = 16) -> None:
        super().__init__()
        if width <= 0 or width % 8:
            raise ValueError("refiner width must be positive and divisible by 8")
        self.baseline = baseline
        for parameter in self.baseline.parameters():
            parameter.requires_grad_(False)
        self.baseline.eval()

        # RGB + baseline logit + Bernoulli entropy.
        self.encoder1 = ConvBlock(5, width)
        self.pool1 = nn.MaxPool2d(2)
        self.encoder2 = ConvBlock(width, 2 * width)
        self.pool2 = nn.MaxPool2d(2)
        self.bottleneck = ConvBlock(2 * width, 4 * width)
        self.up2 = nn.ConvTranspose2d(4 * width, 2 * width, 2, stride=2)
        self.decoder2 = ConvBlock(4 * width, 2 * width)
        self.up1 = nn.ConvTranspose2d(2 * width, width, 2, stride=2)
        self.decoder1 = ConvBlock(2 * width, width)
        self.delta_head = nn.Conv2d(width, 1, 1)
        # The gate is also an explicit auxiliary "ambiguous" category: it marks
        # pixels that should not be treated as confidently foreground/background.
        self.gate_head = nn.Conv2d(width, 1, 1)

        # At initialization final_logits == baseline_logits exactly.
        nn.init.zeros_(self.delta_head.weight)
        nn.init.zeros_(self.delta_head.bias)
        nn.init.zeros_(self.gate_head.weight)
        nn.init.zeros_(self.gate_head.bias)

    def train(self, mode: bool = True) -> "SelectiveResidualRefiner":
        super().train(mode)
        self.baseline.eval()
        return self

    def forward(
        self, images: Tensor, *, return_aux: bool = False
    ) -> dict[str, Tensor]:
        del return_aux
        with torch.no_grad():
            baseline_logits = self.baseline(images, return_aux=False)["seg_logits"].detach()
        # Entropy must be computed in FP32: 1-1e-6 rounds to 1 in FP16 and
        # would make the background logarithm evaluate log(0).
        probability = baseline_logits.float().sigmoid().clamp(1e-6, 1 - 1e-6)
        entropy = -(
            probability * probability.log()
            + (1 - probability) * (1 - probability).log()
        )
        encoder1 = self.encoder1(
            torch.cat((images, baseline_logits, entropy), dim=1)
        )
        encoder2 = self.encoder2(self.pool1(encoder1))
        bottleneck = self.bottleneck(self.pool2(encoder2))
        decoder2 = self.decoder2(torch.cat((self.up2(bottleneck), encoder2), dim=1))
        decoder1 = self.decoder1(torch.cat((self.up1(decoder2), encoder1), dim=1))
        delta = self.delta_head(decoder1)
        gate_logits = self.gate_head(decoder1)
        gate = gate_logits.sigmoid()
        final_logits = baseline_logits + gate * delta
        final_probability = final_logits.float().sigmoid()
        class_probabilities = torch.cat(
            (
                (1 - gate.float()) * (1 - final_probability),
                (1 - gate.float()) * final_probability,
                gate.float(),
            ),
            dim=1,
        )
        return {
            "seg_logits": final_logits,
            "baseline_logits": baseline_logits,
            "delta_logits": delta,
            "gate_logits": gate_logits,
            "ambiguity_logits": gate_logits,
            "ambiguity": gate,
            # Channel order: confident background, confident lesion, ambiguous.
            "class_probabilities": class_probabilities,
        }

    def trainable_parameters(self) -> int:
        return sum(parameter.numel() for parameter in self.parameters() if parameter.requires_grad)


def load_refiner_checkpoint(
    checkpoint_path: str | Path,
    device: str | torch.device,
) -> tuple[SelectiveResidualRefiner, dict[str, Any]]:
    """Restore a compact refiner checkpoint and its referenced frozen baseline."""

    from evaluate import load_model_from_checkpoint

    path = Path(checkpoint_path)
    try:
        checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        checkpoint = torch.load(path, map_location="cpu")
    baseline_path = checkpoint.get("baseline_checkpoint")
    state = checkpoint.get("refiner_state_dict")
    if not isinstance(baseline_path, str) or not isinstance(state, dict):
        raise ValueError("invalid selective-refiner checkpoint")
    baseline = load_model_from_checkpoint(baseline_path, device)[0]
    model = SelectiveResidualRefiner(
        baseline, width=int(checkpoint.get("refiner_width", 16))
    ).to(device)
    model.load_state_dict(state, strict=True)
    return model, checkpoint
