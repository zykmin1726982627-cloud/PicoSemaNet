"""Directional ambiguity-gated correction around a frozen segmenter."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F
from torch import Tensor, nn

from src.selective_refiner import ConvBlock


def _gradient_magnitude(value: Tensor) -> Tensor:
    """Cheap, parameter-free edge magnitude with the input spatial shape."""

    value = value.float()
    horizontal = F.pad(value[..., :, 1:] - value[..., :, :-1], (0, 1, 0, 0))
    vertical = F.pad(value[..., 1:, :] - value[..., :-1, :], (0, 0, 0, 1))
    return (horizontal.square() + vertical.square() + 1e-8).sqrt()


class DirectionalAmbiguityRefiner(nn.Module):
    """Locate FN/FP risk separately and apply sign-constrained logit repairs."""

    def __init__(
        self,
        baseline: nn.Module,
        width: int = 16,
        max_logit_delta: float = 4.0,
        *,
        enable_shape_branch: bool = False,
        max_shape_delta: float = 3.0,
    ) -> None:
        super().__init__()
        if width <= 0 or width % 8:
            raise ValueError("refiner width must be positive and divisible by 8")
        if max_logit_delta <= 0:
            raise ValueError("max_logit_delta must be positive")
        if max_shape_delta <= 0:
            raise ValueError("max_shape_delta must be positive")
        self.baseline = baseline
        self.max_logit_delta = float(max_logit_delta)
        self.enable_shape_branch = bool(enable_shape_branch)
        self.max_shape_delta = float(max_shape_delta)
        for parameter in self.baseline.parameters():
            parameter.requires_grad_(False)
        self.baseline.eval()

        # RGB + baseline logit + entropy + image edge + baseline edge.
        self.encoder1 = ConvBlock(7, width)
        self.pool1 = nn.MaxPool2d(2)
        self.encoder2 = ConvBlock(width, 2 * width)
        self.pool2 = nn.MaxPool2d(2)
        self.bottleneck = ConvBlock(2 * width, 4 * width)
        self.up2 = nn.ConvTranspose2d(4 * width, 2 * width, 2, stride=2)
        self.decoder2 = ConvBlock(4 * width, 2 * width)
        self.up1 = nn.ConvTranspose2d(2 * width, width, 2, stride=2)
        self.decoder1 = ConvBlock(2 * width, width)

        self.fn_gate_head = nn.Conv2d(width, 1, 1)
        self.fp_gate_head = nn.Conv2d(width, 1, 1)
        self.fn_magnitude_head = nn.Conv2d(width, 1, 1)
        self.fp_magnitude_head = nn.Conv2d(width, 1, 1)
        for head in (
            self.fn_gate_head,
            self.fp_gate_head,
            self.fn_magnitude_head,
            self.fp_magnitude_head,
        ):
            nn.init.zeros_(head.weight)
            nn.init.zeros_(head.bias)
        # Sparse initial gates. Identical FN/FP branches still cancel exactly,
        # preserving the baseline before any optimization step.
        nn.init.constant_(self.fn_gate_head.bias, -2.0)
        nn.init.constant_(self.fp_gate_head.bias, -2.0)
        if self.enable_shape_branch:
            # Half-resolution heads yield a smooth, large-context correction for
            # holes and region-scale errors. The zero delta preserves identity.
            self.shape_gate_head = nn.Conv2d(2 * width, 1, 1)
            self.shape_delta_head = nn.Conv2d(2 * width, 1, 1)
            nn.init.zeros_(self.shape_gate_head.weight)
            nn.init.constant_(self.shape_gate_head.bias, -2.0)
            nn.init.zeros_(self.shape_delta_head.weight)
            nn.init.zeros_(self.shape_delta_head.bias)

    def train(self, mode: bool = True) -> "DirectionalAmbiguityRefiner":
        super().train(mode)
        self.baseline.eval()
        return self

    def forward(
        self, images: Tensor, *, return_aux: bool = False
    ) -> dict[str, Tensor]:
        del return_aux
        with torch.no_grad():
            baseline_logits = self.baseline(images, return_aux=False)[
                "seg_logits"
            ].detach()
        probability = baseline_logits.float().sigmoid().clamp(1e-6, 1 - 1e-6)
        entropy = -(
            probability * probability.log()
            + (1 - probability) * (1 - probability).log()
        )
        gray = images.float().mean(dim=1, keepdim=True)
        features = torch.cat(
            (
                images.float(),
                baseline_logits.float(),
                entropy,
                _gradient_magnitude(gray),
                _gradient_magnitude(probability),
            ),
            dim=1,
        )
        encoder1 = self.encoder1(features)
        encoder2 = self.encoder2(self.pool1(encoder1))
        bottleneck = self.bottleneck(self.pool2(encoder2))
        decoder2 = self.decoder2(torch.cat((self.up2(bottleneck), encoder2), dim=1))
        decoder1 = self.decoder1(torch.cat((self.up1(decoder2), encoder1), dim=1))

        fn_gate_logits = self.fn_gate_head(decoder1)
        fp_gate_logits = self.fp_gate_head(decoder1)
        fn_gate = fn_gate_logits.sigmoid()
        fp_gate = fp_gate_logits.sigmoid()
        fn_magnitude = self.max_logit_delta * self.fn_magnitude_head(decoder1).sigmoid()
        fp_magnitude = self.max_logit_delta * self.fp_magnitude_head(decoder1).sigmoid()
        positive_delta = fn_gate * fn_magnitude
        negative_delta = fp_gate * fp_magnitude
        directional_delta = positive_delta - negative_delta
        if self.enable_shape_branch:
            shape_gate_logits = F.interpolate(
                self.shape_gate_head(decoder2),
                size=baseline_logits.shape[-2:],
                mode="bilinear",
                align_corners=False,
            )
            shape_delta_raw = F.interpolate(
                self.shape_delta_head(decoder2),
                size=baseline_logits.shape[-2:],
                mode="bilinear",
                align_corners=False,
            )
            shape_gate = shape_gate_logits.sigmoid()
            shape_delta = self.max_shape_delta * shape_delta_raw.tanh()
            shape_effective = shape_gate * shape_delta
        else:
            shape_gate_logits = torch.full_like(baseline_logits, -20.0).float()
            shape_gate = shape_gate_logits.sigmoid()
            shape_delta = torch.zeros_like(baseline_logits).float()
            shape_effective = shape_delta
        delta = directional_delta + shape_effective
        final_logits = baseline_logits.float() + delta
        return {
            "seg_logits": final_logits,
            "baseline_logits": baseline_logits.float(),
            "delta_logits": delta,
            "fn_gate_logits": fn_gate_logits,
            "fp_gate_logits": fp_gate_logits,
            "fn_gate": fn_gate,
            "fp_gate": fp_gate,
            "ambiguity": torch.maximum(fn_gate, fp_gate),
            "fn_magnitude": fn_magnitude,
            "fp_magnitude": fp_magnitude,
            "positive_delta": positive_delta,
            "negative_delta": negative_delta,
            "directional_delta": directional_delta,
            "shape_gate_logits": shape_gate_logits,
            "shape_gate": shape_gate,
            "shape_delta": shape_delta,
            "shape_effective": shape_effective,
        }

    def trainable_parameters(self) -> int:
        return sum(
            parameter.numel()
            for parameter in self.parameters()
            if parameter.requires_grad
        )


def load_directional_refiner_checkpoint(
    checkpoint_path: str | Path,
    device: str | torch.device,
) -> tuple[DirectionalAmbiguityRefiner, dict[str, Any]]:
    """Restore a directional refiner and its referenced frozen baseline."""

    from evaluate import load_model_from_checkpoint

    path = Path(checkpoint_path)
    try:
        checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        checkpoint = torch.load(path, map_location="cpu")
    baseline_path = checkpoint.get("baseline_checkpoint")
    state = checkpoint.get("refiner_state_dict")
    if not isinstance(baseline_path, str) or not isinstance(state, dict):
        raise ValueError("invalid directional-refiner checkpoint")
    baseline = load_model_from_checkpoint(baseline_path, device)[0]
    model = DirectionalAmbiguityRefiner(
        baseline,
        width=int(checkpoint.get("refiner_width", 16)),
        max_logit_delta=float(checkpoint.get("max_logit_delta", 4.0)),
        enable_shape_branch=bool(checkpoint.get("enable_shape_branch", False)),
        max_shape_delta=float(checkpoint.get("max_shape_delta", 3.0)),
    ).to(device)
    current = model.state_dict()
    current.update(state)
    model.load_state_dict(current, strict=True)
    return model, checkpoint


__all__ = ["DirectionalAmbiguityRefiner", "load_directional_refiner_checkpoint"]
