"""Audit table inputs and independently check every proposed seed-42 mask in NumPy."""
from pathlib import Path
import csv
import json
import statistics
import sys
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent

def boundary(mask):
    padded = np.pad(mask, ((0,0),(1,1),(1,1)), mode="edge")
    maximum = np.zeros_like(mask)
    minimum = np.ones_like(mask)
    height, width = mask.shape[-2:]
    for dy in range(3):
        for dx in range(3):
            neighbor = padded[:,dy:dy+height,dx:dx+width]
            maximum |= neighbor
            minimum &= neighbor
    return maximum & ~minimum

def disk_band(mask):
    padded = np.pad(mask, ((0,0),(2,2),(2,2)), mode="constant")
    band = np.zeros_like(mask)
    height, width = mask.shape[-2:]
    for dy in range(-2,3):
        for dx in range(-2,3):
            if dy*dy+dx*dx <= 4:
                band |= padded[:,2+dy:2+dy+height,2+dx:2+dx+width]
    return band

def independent_bf1(pred, target):
    bp, br = boundary(pred), boundary(target)
    dp, dr = disk_band(bp), disk_band(br)
    np_, nr = bp.sum((1,2)), br.sum((1,2))
    precision = (bp & dr).sum((1,2))/np.maximum(np_,1)
    recall = (br & dp).sum((1,2))/np.maximum(nr,1)
    scores = 2*precision*recall/np.maximum(precision+recall,1e-6)
    both_empty = (np_==0)&(nr==0)&(pred==target).all((1,2))
    scores[both_empty] = 1
    return scores

def main():
    summary = json.loads((ROOT/"results/summary.json").read_text())
    assert summary["completed"] == summary["expected"] == 47
    assert len(summary["groups"]) == 19
    assert len({run["run"] for run in summary["runs"]}) == 47
    split = json.loads((ROOT/"baseline_source/data/ISIC2018/paper_split_70_10_20_seed20260912.json").read_text())
    ids = split["test"]
    largest_replay_difference = {metric:0 for metric in ["dice", "iou", "accuracy", "bf1"]}
    rows_by_run = {}
    for run in summary["runs"]:
        assert run["num_images"] == 520
        path = ROOT/"results"/run["run"]/"per_image_metrics.csv"
        rows = list(csv.DictReader(path.open(encoding="utf-8", newline="")))
        assert [r["id"] for r in rows] == ids
        rows_by_run[run["run"]] = rows
        for metric in ["dice", "iou", "accuracy", "bf1_square", "bf1_euclidean"]:
            assert abs(statistics.mean(float(r[metric]) for r in rows)-run[metric]) < 1e-12
        assert all(float(r["bf1_euclidean"]) <= float(r["bf1_square"])+1e-6 for r in rows)
        for metric, delta in run["replay_minus_original"].items():
            largest_replay_difference[metric] = max(largest_replay_difference[metric], abs(delta)*100)
    for group in summary["groups"].values():
        members = [run for run in summary["runs"] if run["run"] in group["runs"]]
        for metric in ["dice", "iou", "accuracy", "bf1_square", "bf1_euclidean"]:
            values = [run[metric] for run in members]
            assert abs(statistics.mean(values)-group[metric+"_mean"]) < 1e-12
            if len(values)>1:
                assert abs(statistics.stdev(values)-group[metric+"_std"]) < 1e-12
    run = next(r for r in summary["runs"] if r["group"]=="proposed" and r["seed"]==42)
    masks = np.load(ROOT/"results"/run["run"]/"predicted_masks.npz", allow_pickle=False)
    assert masks["ids"].tolist() == ids
    pred = np.unpackbits(masks["masks_packbits"], axis=-1).astype(bool)
    target = np.empty_like(pred)
    for index, image_id in enumerate(ids):
        with Image.open(Path("F:/Datasets/ISIC2018/masks")/f"{image_id}_segmentation.png") as f:
            target[index] = np.asarray(f.convert("L").resize((320,320), Image.Resampling.NEAREST))>0
    independent = independent_bf1(pred,target)
    recorded = np.array([float(r["bf1_euclidean"]) for r in rows_by_run[run["run"]]])
    max_error = float(np.max(np.abs(independent-recorded)))
    assert max_error < 1e-6
    report = {"status":"PASS", "runs":47, "groups":19, "images_per_run":520,
              "per_image_records":47*520, "independent_numpy_checked_masks":520,
              "independent_numpy_max_absolute_error":max_error,
              "largest_absolute_cpu_replay_minus_original_percentage_points":largest_replay_difference}
    (ROOT/"verification.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps(report,indent=2))

if __name__=="__main__": main()
