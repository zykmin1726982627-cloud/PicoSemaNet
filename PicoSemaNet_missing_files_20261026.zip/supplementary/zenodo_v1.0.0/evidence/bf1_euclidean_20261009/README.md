# Euclidean BF1 reevaluation, 2026-10-09

This directory keeps the original evidence separate from the revised boundary metric. No model is retrained, and validation-Dice checkpoint selection is unchanged.

## Metric

- Binary prediction: sigmoid(logits) >= 0.5. Reference: original mask > 0, resized with nearest-neighbor interpolation.
- Images: RGB, bilinear resize to 320 x 320, float32 / 255, then (x - 0.5) / 0.5.
- Both binary masks use the archived 3 x 3 square morphological gradient, dilation minus erosion. Neighborhoods at image borders include in-image pixels only.
- The tolerance is two pixels in the 320 x 320 grid, measured by Euclidean distance between pixel centers. The radius-two discrete disk has 13 offsets; offset (2,2) is excluded.
- Both boundary maps are dilated independently with that disk. Precision = predicted boundary pixels in the reference band / predicted boundary count. Recall reverses prediction and reference. Each pixel counts once, with many-to-many correspondence allowed.
- BF1 = 2PR/(P+R), or zero when P+R = 0. One empty boundary scores zero. If both boundaries are empty, the score is one only when the masks are identical, otherwise zero.
- Average BF1 across the fixed 520 images, then compute mean and sample SD across seeds 42, 43, 44 for each multi-seed table row.

The previous metric used a 5 x 5 square band (Chebyshev tolerance). Its scores must not be relabeled as Euclidean BF1. `baseline_source` remains an unmodified copy of the original supplement.

## Data and checkpoints

Official source: https://challenge.isic-archive.com/data/

`fetch_test_data.py` reads the official training image and ground-truth ZIP directories using HTTP ranges and downloads only the paper's 520 internal test pairs. It verifies official ZIP length/CRC32 and records each SHA-256 in `test_download_manifest.json`. These files are an internal test subset, not the hidden official challenge test set or the complete 2,594-pair training dataset.

Split SHA-256: `ff709315d972d602969d1da5815170abade7d0c08fa0d8c09264968a80df5228`.

`prepare_runs.py` selects 47 pre-existing best checkpoints for all 26 BF1 table cells. `run_manifest.json` records group membership, original metrics, source archive members, checkpoint hashes, and training configurations. Model weights and ISIC images are not redistributed in the updated supplement.

## Reproduce

Use a Python environment with PyTorch 2.14.0, NumPy 2.4.4, and Pillow 12.2.0 for the recorded CPU replay. The local evaluation uses Python 3.13, float32, batch size 8, four CPU threads, and auxiliary outputs disabled.

```powershell
python fetch_test_data.py --destination F:\Datasets\ISIC2018
python bf1_euclidean.py
python reevaluate.py --dataset-root F:\Datasets\ISIC2018 --checkpoint-root PATH_TO_SELECTED_CHECKPOINTS --threads 4 --batch-size 8
```

The checkpoint directory must contain the run paths from `run_manifest.json`, with `best.pt` in each run directory. `reevaluate.py` validates hashes, restores weights strictly, and verifies checkpoint seed, model name, and epoch against the original evaluation record.

## Outputs

`results/summary.json` aggregates completed runs. Each run retains per-image Dice, IoU, accuracy, old square BF1, and new Euclidean BF1 in `per_image_metrics.csv`, together with original GPU metrics and CPU provenance in `metrics.json`. Local packed binary masks are saved for independent metric checking. The supplement includes the metric records and code, but omits the packed masks to keep its size manageable.

`bf1_table_changes.json` maps all replaced manuscript BF1 values to the new results. The manuscript preserves the original GPU Dice/IoU and identifies the CPU Euclidean BF1 reevaluation separately. Numerical replay differences are recorded explicitly; they are not assumed to be explained by the hardware change.
