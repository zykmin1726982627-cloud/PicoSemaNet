"""BF1 with a radius-two Euclidean disk; all other semantics match archived evaluation."""
from pathlib import Path
import sys
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "baseline_source"))
from src.metrics import _pair, _boundary, _reduce

def euclidean_band(boundary, tolerance=2):
    axis = torch.arange(-tolerance, tolerance + 1, device=boundary.device)
    disk = (axis[:, None].square() + axis[None, :].square() <= tolerance ** 2)
    return F.conv2d(boundary.float(), disk.float()[None, None], padding=tolerance) > 0

def euclidean_boundary_f1_score(prediction, target, *, tolerance=2, threshold=0.5,
                               from_logits=False, reduction="mean", epsilon=1e-6):
    if isinstance(tolerance, bool) or not isinstance(tolerance, int) or tolerance < 0:
        raise ValueError("tolerance must be a non-negative integer")
    if epsilon <= 0: raise ValueError("epsilon must be positive")
    prediction, target = _pair(prediction, target, threshold, from_logits)
    bp, br = _boundary(prediction), _boundary(target)
    dp, dr = euclidean_band(bp, tolerance), euclidean_band(br, tolerance)
    np, nr = bp.flatten(1).sum(1, dtype=torch.float32), br.flatten(1).sum(1, dtype=torch.float32)
    precision = (bp & dr).flatten(1).sum(1, dtype=torch.float32) / np.clamp_min(epsilon)
    recall = (br & dp).flatten(1).sum(1, dtype=torch.float32) / nr.clamp_min(epsilon)
    score = 2 * precision * recall / (precision + recall).clamp_min(epsilon)
    empty = (np == 0) & (nr == 0)
    equal = (prediction == target).flatten(1).all(1)
    score = torch.where(empty & equal, torch.ones_like(score), score)
    return _reduce(score, reduction)

def verify():
    from src.metrics import boundary_f1_score
    torch.set_num_threads(2)
    point = torch.zeros(1, 1, 11, 11, dtype=torch.bool)
    point[0,0,5,5] = True
    disk = euclidean_band(point)
    assert disk.sum().item() == 13
    assert disk[0,0,5,7] and not disk[0,0,7,7]
    blank=torch.zeros(1,1,11,11,dtype=torch.bool)
    full=torch.ones_like(blank)
    assert euclidean_boundary_f1_score(blank,blank).item()==1
    assert euclidean_boundary_f1_score(full,full).item()==1
    assert euclidean_boundary_f1_score(blank,full).item()==0
    assert euclidean_boundary_f1_score(point,blank).item()==0
    assert euclidean_boundary_f1_score(point,point).item()==1
    generator=torch.Generator().manual_seed(20261009)
    for trial in range(12):
        p=torch.rand(1,1,13,17,generator=generator)>.7
        r=torch.rand(1,1,13,17,generator=generator)>.7
        bp,br=_boundary(p)[0,0],_boundary(r)[0,0]
        cp,cr=bp.nonzero(),br.nonzero()
        distance=(cp[:,None,:]-cr[None,:,:]).square().sum(-1)
        prec=(distance.min(1).values<=4).float().mean()
        rec=(distance.min(0).values<=4).float().mean()
        expected=2*prec*rec/(prec+rec).clamp_min(1e-6)
        got=euclidean_boundary_f1_score(p,r)
        assert torch.allclose(got,expected,atol=1e-6)
        assert got<=boundary_f1_score(p,r)+1e-6
    print("PASS: disk geometry, empty-mask conventions, 12 brute-force Euclidean comparisons",flush=True)

if __name__=="__main__": verify()
