"""Fetch the exact 520-image paper test split from official ZIPs using HTTP ranges."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse, io, json, zipfile, urllib.request, struct, zlib, hashlib, time, threading

ROOT = Path(__file__).resolve().parent
DEST = Path(r"F:\Datasets\ISIC2018")
SPLIT = ROOT / "baseline_source/data/ISIC2018/paper_split_70_10_20_seed20260912.json"
BASE = "https://isic-archive.s3.amazonaws.com/challenges/2018/"
URLS = {"images": BASE + "ISIC2018_Task1-2_Training_Input.zip",
        "masks": BASE + "ISIC2018_Task1_Training_GroundTruth.zip"}
LOCK = threading.Lock()

def request(url, start=None, end=None):
    headers = {"User-Agent": "ISIC-paper-reproducibility/1.0"}
    if start is not None:
        headers["Range"] = f"bytes={start}-{end}"
    for attempt in range(4):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=90) as response:
                if start is not None and response.status != 206:
                    raise RuntimeError(f"Server did not honor Range: {response.status}")
                return response.read()
        except Exception:
            if attempt == 3: raise
            time.sleep(1 + attempt)

class RangeReader(io.RawIOBase):
    def __init__(self, url):
        self.url, self.position = url, 0
        with urllib.request.urlopen(urllib.request.Request(url, method="HEAD"), timeout=45) as response:
            self.length = int(response.headers["Content-Length"])
    def readable(self): return True
    def seekable(self): return True
    def tell(self): return self.position
    def seek(self, offset, whence=0):
        self.position = offset if whence == 0 else self.position + offset if whence == 1 else self.length + offset
        return self.position
    def read(self, size=-1):
        size = self.length - self.position if size < 0 else min(size, self.length - self.position)
        if size <= 0: return b""
        data = request(self.url, self.position, self.position + size - 1)
        self.position += len(data)
        return data

def fetch_entry(url, entry, kind):
    destination = DEST / kind / Path(entry.filename).name
    if destination.exists():
        data = destination.read_bytes()
        if len(data) == entry.file_size and zlib.crc32(data) == entry.CRC:
            return dict(path=str(destination), bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), source=url, crc32=entry.CRC)
    data = request(url, entry.header_offset, entry.header_offset + entry.compress_size + 65535 + 30)
    header = struct.unpack("<4s5H3I2H", data[:30])
    if header[0] != b"PK\x03\x04": raise ValueError("Invalid local ZIP header")
    start = 30 + header[-2] + header[-1]
    compressed = data[start:start + entry.compress_size]
    raw = zlib.decompress(compressed, -15) if entry.compress_type == zipfile.ZIP_DEFLATED else compressed
    if entry.compress_type not in (zipfile.ZIP_DEFLATED, zipfile.ZIP_STORED): raise ValueError("Unsupported ZIP method")
    if len(raw) != entry.file_size or zlib.crc32(raw) != entry.CRC: raise ValueError(f"ZIP CRC mismatch: {entry.filename}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".partial")
    temporary.write_bytes(raw)
    temporary.replace(destination)
    return dict(path=str(destination), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), source=url, crc32=entry.CRC)

def main():
    global DEST
    parser = argparse.ArgumentParser()
    parser.add_argument("--destination", type=Path, default=DEST)
    arguments = parser.parse_args()
    DEST = arguments.destination
    split = json.loads(SPLIT.read_text(encoding="utf-8"))
    ids = split["test"]
    assert len(ids) == 520 and len(set(ids)) == 520
    DEST.mkdir(parents=True, exist_ok=True)
    records, jobs = [], []
    for kind, url in URLS.items():
        reader = RangeReader(url)
        with zipfile.ZipFile(reader) as archive:
            names = {Path(item.filename).name: item for item in archive.infolist()}
        for sample in ids:
            filename = sample + (".jpg" if kind == "images" else "_segmentation.png")
            if filename not in names: raise KeyError(f"Missing official image: {filename}")
            jobs.append((url, names[filename], kind))
        print(json.dumps({"kind":kind,"archive_bytes":reader.length,"selected_files":len(ids),"selected_bytes":sum(j[1].file_size for j in jobs if j[2]==kind)}), flush=True)
    total, started = len(jobs), time.time()
    failures=[]
    with ThreadPoolExecutor(max_workers=6) as executor:
        futures = {executor.submit(fetch_entry, *job): job for job in jobs}
        for future in as_completed(futures):
            try: records.append(future.result())
            except Exception as error: failures.append({"file":futures[future][1].filename,"error":str(error)})
            completed=len(records)+len(failures)
            if completed % 20 == 0 or completed == total:
                print(json.dumps({"complete":completed,"total":total,"ok":len(records),"failed":len(failures),"seconds":round(time.time()-started)}), flush=True)
                (DEST/"download_progress.json").write_text(json.dumps(dict(records=records, failures=failures),indent=2))
    metadata=dict(official_page="https://challenge.isic-archive.com/data/",urls=URLS,scope="fixed internal paper test split only",test_count=520,split_sha256=hashlib.sha256(SPLIT.read_bytes()).hexdigest(),records=records,failures=failures)
    (DEST/"test_download_manifest.json").write_text(json.dumps(metadata,indent=2))
    if failures: raise RuntimeError(f"{len(failures)} downloads failed; rerun resumes verified files")
    print("TEST_DATA_READY",flush=True)

if __name__ == "__main__": main()
