"""Write the concise review record from finished results and table mappings."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent

def main():
    verification = json.loads((ROOT/"verification.json").read_text())
    changes = json.loads((ROOT/"bf1_table_changes.json").read_text())
    summary = json.loads((ROOT/"results/summary.json").read_text())
    data = json.loads(Path("F:/Datasets/ISIC2018/test_download_manifest.json").read_text())
    assert verification["status"]=="PASS" and summary["completed"]==47
    groups = summary["groups"]
    def display(group):
        g=groups[group]
        return f"{100*g['bf1_euclidean_mean']:.2f} ± {100*g['bf1_euclidean_std']:.2f}%"
    lines = [
        "# BF1 修改与复算记录（2026-10-09）", "",
        "本次完成教授第三点要求：把 BF1 改为两像素欧氏距离匹配，补齐可复现定义，并重算现有论文表格。使用已有最佳验证 Dice 检查点，没有重新训练模型。", "",
        "## 输入与范围", "",
        "- 数据：ISIC 官方训练数据中论文固定的 520 个内部测试图像–标注对，保存于 `F:\\Datasets\\ISIC2018`，共 2,317,094,137 字节。不是完整训练数据集或官方隐藏测试集。",
        "- 数据来源：https://challenge.isic-archive.com/data/ 。每个文件已核对官方 ZIP 的长度、CRC32，并记录、复核 SHA-256。四对已有示例也逐字节相同。",
        f"- 固定划分 SHA-256：`{data['split_sha256']}`。",
        "- 权重：47 份已有 best.pt，覆盖 19 组配置、论文 26 个 BF1 表格单元。加载时检查权重 SHA-256、模型、种子、检查点 epoch，并严格恢复模型参数。", "",
        "## 本地原稿修改", "",
        "- 3×3 形态学梯度分别提取预测和参考边界，说明图像边缘只使用图内邻域。",
        "- 容差是 320×320 评价空间中的两像素欧氏距离；预测和参考边界各自使用半径 2 的离散圆盘膨胀。",
        "- 给出精确的 precision、recall 和 BF1 公式，逐像素一次计数、允许多对多匹配，并定义空边界的结果。",
        "- 更新三张表的全部 26 个 BF1 值，以及摘要和相关结果句子。参数、MACs、验证 Dice、原始 GPU Dice/IoU 保持原有数据来源。",
        "- 说明 BF1 为 CPU/PyTorch 2.14.0 的 FP32 复算；原始 GPU/PyTorch 2.11.0 的评价记录保留在补充材料。", "",
        "## 主要结果", "",
        f"- 当前原稿 Full FPFCS（含 EC）：{display('proposed')}。",
        f"- 当前原稿 No FPFCS（Seg+KD+EC）：{display('no_fpfcs')}。",
        f"- 无 EC 的 FPFCS 配置：{display('no_ec')}。",
        "- 新欧氏 BF1 下，当前 Full FPFCS 的均值没有高于 No FPFCS；结果文字已避免继续声称 BF1 优势。这里尚未把无 EC 配置改为论文 Proposed，也没有完成教授另行要求的 100 epochs × 3 seeds 新实验。", "",
        "## 验证", "",
        "- **通过**：全部 47×520=24,440 条逐图记录完整，图像顺序与固定列表相同。",
        "- **通过**：逐图均值、三种子均值及样本标准差重新聚合一致。",
        "- **通过**：全部逐图欧氏 BF1 不超过同一次 CPU 预测的方形 BF1。",
        f"- **通过**：独立 NumPy 实现核对 seed-42 Full FPFCS 的全部 520 张预测；最大绝对误差 `{verification['independent_numpy_max_absolute_error']:.3g}`。",
        "- **记录差异**：CPU 复算与原始 GPU 结果并不完全相同；下列差异为各运行测试均值的最大绝对差，单位为百分点，原因未被实验证实。", "",
        "| 指标 | 最大 CPU–原始 GPU 差异（百分点） |", "|---|---:|",
    ]
    for metric, value in verification["largest_absolute_cpu_replay_minus_original_percentage_points"].items():
        lines.append(f"| {metric} | {value:.6f} |")
    lines += ["", "## 表格数值对应", "", "旧值是原稿中的 GPU 方形容差 BF1；新值是同一检查点的 CPU 欧氏容差 BF1。评价规则和运行环境均已明确记录。", "",
              "| 表 | 行 | 原稿 BF1 | 新 BF1 |", "|---|---|---|---|"]
    for row in changes["changes"]:
        lines.append(f"| {row['table']} | {row['row']} | `{row['old_bf1']}` | `{row['new_bf1']}` |")
    lines += ["", "## 交付与当前边界", "",
        "- `sn-article.tex`：在原有编辑器中原位修改。",
        "- `results/`：所有复算输出；`verification.json`：独立检查。",
        "- `Online_Resource_1_reproducibility.zip`：保留历史结果并增加欧氏 BF1 的代码、逐图指标、来源和哈希。旧 ZIP 和修改前原稿保留在本目录。",
        "- 只更新本地文件；Overleaf 在线项目未上传本次更改。",
        "- LaTeX 编译状态以最后一次内置编译器诊断为准。", ""]
    (ROOT/"AUDIT_CN.md").write_text("\n".join(lines),encoding="utf-8")
    print("AUDIT_WRITTEN")

if __name__=="__main__": main()
