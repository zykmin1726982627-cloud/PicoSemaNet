"""Durable six-run queue: 100 full epochs, EC off, paired FPFCS +/- KD controls."""

from __future__ import annotations

import argparse
import csv
import fcntl
import hashlib
import json
import os
import statistics
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

PROJECT = Path(__file__).resolve().parent
ROOT = PROJECT / "formal_paper_professor_fpfcs_100ep_v1"
MANIFEST = ROOT / "queue.json"
SPLIT = "data/ISIC2018/paper_split_70_10_20_seed20260912.json"
TEACHER = "formal_paper_seed42_v1/teacher_performance_context_seed42/best.pt"
SOURCES = ("train.py", "evaluate.py", "src/metrics.py", "src/losses.py", "src/models.py", "src/dataset.py", "src/utils.py", "run_professor_fpfcs_100epoch.py")


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest() if hasattr(hashlib, "file_digest") else hashlib.sha256(handle.read()).hexdigest()


def save(payload, path):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def command(group, seed):
    weights = (0.18, 0.05, 0.12) if group == "full_fpfcs" else (0, 0, 0)
    name = f"{group}_seed{seed}"
    return [str(PROJECT / ".venv/bin/python"), "-u", "train.py",
            "--data-root", "data/ISIC2018", "--splits-path", SPLIT,
            "--output-dir", str(ROOT / name), "--seed", str(seed),
            "--model", "picolite_fullpath_distill", "--base-channels", "4",
            "--image-size", "320", "--batch-size", "8", "--epochs", "100",
            # Patience exceeds the entire budget, so no early stop can fire.
            "--early-stopping-patience", "101", "--learning-rate", "0.001",
            "--weight-decay", "0.0001", "--scheduler-patience", "5",
            "--scheduler-factor", "0.5", "--min-learning-rate", "0.000001",
            "--num-workers", "8", "--device", "cuda:0", "--amp",
            "--batch-cooldown-ms", "0", "--num-predictions", "0",
            "--benchmark-warmup-batches", "5", "--benchmark-batches", "20",
            "--benchmark-repetitions", "5", "--teacher-checkpoint", TEACHER,
            "--ema-decay", "0.995", "--aux-warmup-epochs", "8", "--auxiliary-floor", "0.15",
            "--lambda-boundary", str(weights[0]), "--lambda-texture", str(weights[1]),
            "--lambda-sdf", str(weights[2]), "--lambda-distill", "0.25",
            "--distill-temperature", "2", "--lambda-edge", "0",
            "--lambda-shape", "0", "--lambda-ambiguity", "0", "--max-ambiguity-to-seg-ratio", "0",
            "--lambda-deep-supervision", "0", "--max-deep-to-seg-ratio", "0",
            "--max-aux-to-seg-ratio", "0.25", "--threshold", "0.5",
            "--boundary-tolerance", "2", "--boundary-distance", "euclidean"]


def prepare():
    from train import TrainConfig, _validate, build_parser

    if MANIFEST.exists():
        return json.loads(MANIFEST.read_text(encoding="utf-8"))
    ROOT.mkdir(parents=True, exist_ok=True)
    split = json.loads((PROJECT / SPLIT).read_text())
    sets = [set(split[key]) for key in ("train", "val", "test")]
    if any(sets[i] & sets[j] for i in range(3) for j in range(i + 1, 3)):
        raise ValueError("Data splits overlap")
    for ids in sets:
        for image_id in ids:
            for path in (PROJECT / f"data/ISIC2018/images/{image_id}.jpg",
                         PROJECT / f"data/ISIC2018/masks/{image_id}_segmentation.png"):
                if not path.is_file():
                    raise FileNotFoundError(path)
    entries = []
    parser = build_parser()
    for seed in (42, 43, 44):
        for group in ("full_fpfcs", "no_fpfcs"):
            argv = command(group, seed)
            config = TrainConfig(**vars(parser.parse_args(argv[3:])))
            _validate(config)
            entries.append(dict(name=f"{group}_seed{seed}", group=group, seed=seed,
                                status="pending", command=argv, output_dir=str(config.output_dir)))
    queue = dict(created_at=now(), status="pending", protocol="100 complete epochs; best validation Dice checkpoint; EC=0; KD=0.25; paired seeds 42/43/44",
                 split_counts={key: len(split[key]) for key in ("train", "val", "test")},
                 sha256={path: digest(PROJECT / path) for path in (*SOURCES, SPLIT, TEACHER)},
                 runs=entries)
    save(queue, MANIFEST)
    return queue


def summarize(queue):
    rows = []
    for run in queue["runs"]:
        path = Path(run["output_dir"]) / "test_metrics.json"
        if run["status"] == "completed":
            metrics = json.loads(path.read_text())
            rows.append({"group": run["group"], "seed": run["seed"],
                         **{key: metrics[key] for key in ("dice", "bf1", "iou", "accuracy", "epochs_completed", "best_epoch", "best_val_dice", "inference_parameters")}})
    with (ROOT / "results_per_seed.csv").open("w", newline="") as handle:
        fields = ["group", "seed", "dice", "bf1", "iou", "accuracy", "epochs_completed", "best_epoch", "best_val_dice", "inference_parameters"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    summary = {"completed_runs": len(rows), "expected_runs": 6, "groups": {}, "paired_deltas": []}
    for group in ("full_fpfcs", "no_fpfcs"):
        selected = [row for row in rows if row["group"] == group]
        summary["groups"][group] = {"n": len(selected), "metrics": {}}
        for metric in ("dice", "bf1", "iou", "accuracy"):
            values = [row[metric] for row in selected]
            summary["groups"][group]["metrics"][metric] = dict(mean=statistics.mean(values) if values else None,
                                                                std=statistics.stdev(values) if len(values) > 1 else None)
    for seed in (42, 43, 44):
        pair = {row["group"]: row for row in rows if row["seed"] == seed}
        if len(pair) == 2:
            summary["paired_deltas"].append({"seed": seed, **{metric: pair["full_fpfcs"][metric] - pair["no_fpfcs"][metric] for metric in ("dice", "bf1", "iou", "accuracy")}})
    deltas = summary["paired_deltas"]
    summary["paired_delta_summary"] = {metric: dict(n=len(deltas), mean=statistics.mean([row[metric] for row in deltas]) if deltas else None,
                                                  std=statistics.stdev([row[metric] for row in deltas]) if len(deltas) > 1 else None)
                                       for metric in ("dice", "bf1", "iou", "accuracy")}
    save(summary, ROOT / "summary.json")


def run_queue(queue):
    import torch

    for path, expected in queue["sha256"].items():
        if digest(PROJECT / path) != expected:
            raise RuntimeError(f"Protocol input changed after registration: {path}")
    # Check actual CUDA execution; NVML/nvidia-smi is not needed for training.
    tensor = torch.ones(1, device="cuda:0")
    torch.cuda.synchronize()
    queue.update(status="running", worker_pid=os.getpid(), started_at=now(),
                 device_name=torch.cuda.get_device_name(0), cuda_probe=float(tensor.item()))
    save(queue, MANIFEST)
    for entry in queue["runs"]:
        if entry["status"] == "completed":
            continue
        output = Path(entry["output_dir"])
        if output.exists() and any(output.iterdir()):
            raise RuntimeError(f"Refusing to overwrite incomplete run: {output}")
        entry.update(status="running", started_at=now())
        queue["active_run"] = entry["name"]
        save(queue, MANIFEST)
        print(f"{now()} START {entry['name']}", flush=True)
        log = ROOT / f"{entry['name']}.log"
        with log.open("a") as handle:
            process = subprocess.Popen(entry["command"], cwd=PROJECT, stdout=handle, stderr=subprocess.STDOUT)
            entry["pid"] = process.pid
            save(queue, MANIFEST)
            returncode = process.wait()
        entry.update(returncode=returncode, finished_at=now())
        if returncode:
            entry["status"] = "failed"
            save(queue, MANIFEST)
            raise RuntimeError(f"{entry['name']} failed ({returncode}); inspect {log}")
        metrics = json.loads((output / "test_metrics.json").read_text())
        if metrics["epochs_completed"] != 100 or metrics["inference_parameters"] != 4844:
            entry["status"] = "failed"
            save(queue, MANIFEST)
            raise RuntimeError("Completed run does not meet the 100-epoch/4,844-parameter protocol")
        entry["status"] = "completed"
        save(queue, MANIFEST)
        summarize(queue)
        print(f"{now()} DONE {entry['name']}", flush=True)
    queue.update(status="completed", active_run=None, finished_at=now())
    save(queue, MANIFEST)
    print("ALL SIX PROFESSOR FPFCS CONTROLS COMPLETE", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--status", action="store_true")
    args = parser.parse_args()
    os.chdir(PROJECT)
    ROOT.mkdir(parents=True, exist_ok=True)
    with (ROOT / "queue.lock").open("a") as lock:
        if args.status:
            print(MANIFEST.read_text(encoding="utf-8"))
            return
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        queue = prepare()
        if args.prepare_only:
            print(f"Registered {len(queue['runs'])} runs in {MANIFEST}")
            return
        try:
            run_queue(queue)
        except Exception as exc:
            queue.update(status="failed", error=str(exc), finished_at=now())
            save(queue, MANIFEST)
            raise


if __name__ == "__main__":
    main()
