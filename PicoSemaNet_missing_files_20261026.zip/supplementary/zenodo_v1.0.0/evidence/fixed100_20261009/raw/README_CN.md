# PicoSemaNet：FPFCS 固定 100 轮、三种子新增实验说明

生成日期：2026-10-09。全部训练完成于北京时间 2026-10-09 07:14:52。这是本轮教授要求的六次新增实验包，不包含旧批次实验结果。

## 1. 实验目的与范围

在相同数据、推理主干、KD 配置和 100 轮训练预算下，比较 Full FPFCS 与 No FPFCS。两组均移除 EC（最终分割 mask 的 edge consistency 损失权重为零），保留 KD。FPFCS 的边界辅助监督仍属于 Full 组的一部分，不能把关闭 EC 理解为关闭 FPFCS 边界监督。

共六次从头训练：Full 42 → No FPFCS 42 → Full 43 → No FPFCS 43 → Full 44 → No FPFCS 44。所有运行均正常完成 100 轮并进行了最终测试。以验证 Dice 选取最佳 checkpoint，测试集不参与选模。

## 2. 固定协议

- 模型：PicoSemaNet，代码标识 `picolite_fullpath_distill`，base_channels=4；推理参数 4,844，含训练辅助模块的总参数 4,928。
- Full 组：Segmentation + 九阶段 FPFCS + KD；boundary/texture/SDF 权重分别为 0.18/0.05/0.12。
- No FPFCS 组：只将上述三个 FPFCS 损失权重设为零，保留同一结构、固定教师及 KD，其他共同训练配置保持一致。
- 两组 KD 权重 0.25，温度 2，教师为 `formal_paper_seed42_v1/teacher_performance_context_seed42/best.pt`（performance_context，第 56 轮 checkpoint）。
- 两组 `lambda_edge=0`，decoder deep supervision 权重为零；不额外引入 shape/ambiguity 损失。
- ISIC2018 锁定划分：`paper_split_70_10_20_seed20260912.json`，训练 1,815、验证 259、测试 520 张；不截断样本。
- 320×320，batch 8，CUDA AMP，AdamW，初始学习率 0.001，weight decay 0.0001。
- ReduceLROnPlateau 使用验证 Dice，patience=5，factor=0.5，最低学习率 1e-6；EMA=0.995。
- 辅助项 warmup=8 轮，floor=0.15，aux/seg cap=0.25。
- 完整训练 100 轮；early-stopping patience=101，保证本批不会提前停止。这与历史“最多 200 轮、patience=40”协议不同。
- best.pt 保存最高验证 Dice 对应的模型状态（启用 EMA 时为 EMA 权重）；训练结束后载入 best.pt，在测试集上评估一次。

完整参数及实际启动命令见各运行 `config.json` 和 `queue.json`。原始 JSON 内的绝对输出路径是原运行记录，换机器后需使用新的本地输出路径。

## 3. BF1 的精确定义

最终分割 logits 经 sigmoid 后以 0.5 二值化；参考 mask 以 0.5 二值化。预测与参考均在 320×320 评估空间，以 3×3 形态学梯度（膨胀减腐蚀）提取边界像素。

容差单位是上述评估空间中的像素，距离度量为欧氏距离，阈值为 2 像素。预测和参考边界分别用离散圆盘膨胀，圆盘覆盖 dx²+dy²≤4 的位移。

- Precision：预测边界中距任意参考边界像素不超过 2 像素的比例。
- Recall：参考边界中距任意预测边界像素不超过 2 像素的比例。
- 邻域存在性匹配，允许多对多，不采用一对一匹配。
- BF1 = 2PR/(P+R)。P+R=0 时 BF1=0；双边界为空且 mask 相同时记为 1，单边为空时记为 0。
- Dice、BF1、IoU、Accuracy 均先按图像计算，再对测试图像取均值；随后对三个种子统计均值和样本标准差（ddof=1）。

**本批显式使用 `--boundary-distance euclidean --boundary-tolerance 2`。历史结果使用 Chebyshev 方形邻域容差，其 BF1 不能直接与本批 BF1 混用。**

## 4. 三种子测试结果

以下是 0–1 标度的均值 ± 样本标准差。

| 方法 | Dice | BF1 | IoU | Accuracy |
|---|---:|---:|---:|---:|
| Full FPFCS + KD | 0.873521 ± 0.000193 | 0.458077 ± 0.006411 | 0.798077 ± 0.000194 | 0.953132 ± 0.000710 |
| No FPFCS + KD | 0.871378 ± 0.001293 | 0.452530 ± 0.009333 | 0.794899 ± 0.001953 | 0.952712 ± 0.001438 |

| 方法 | Seed | Dice | BF1 | IoU | 最佳验证轮次 |
|---|---:|---:|---:|---:|---:|
| Full FPFCS + KD | 42 | 0.873313 | 0.464891 | 0.798029 | 100 |
| No FPFCS + KD | 42 | 0.870005 | 0.458183 | 0.793480 | 92 |
| Full FPFCS + KD | 43 | 0.873554 | 0.457177 | 0.797912 | 93 |
| No FPFCS + KD | 43 | 0.872571 | 0.457650 | 0.797127 | 100 |
| Full FPFCS + KD | 44 | 0.873696 | 0.452165 | 0.798291 | 99 |
| No FPFCS + KD | 44 | 0.871558 | 0.441758 | 0.794091 | 100 |

同种子 Full−No FPFCS 的差值（下表单位为百分点，即原始指标差值 ×100）：

| Seed | ΔDice | ΔBF1 | ΔIoU |
|---|---:|---:|---:|
| 42 | +0.3309 | +0.6708 | +0.4549 |
| 43 | +0.0982 | -0.0473 | +0.0785 |
| 44 | +0.2137 | +1.0407 | +0.4199 |

平均 Dice 提升 0.2143 个百分点，平均 BF1 提升 0.5547 个百分点，平均 IoU 提升 0.3178 个百分点。三个种子的 Dice 均提高；BF1 两个种子提高，seed 43 略降。本批支持小幅、跨种子一致的 Dice 改善，不据此宣称统计显著性。未进行显著性检验。

## 5. 包内文件

- `formal_paper_professor_fpfcs_100ep_v1/results_per_seed.csv`：六次实验的原始汇总。
- 同目录 `summary.json`：两组均值/标准差、每个种子的配对差值和配对差值汇总。
- 六个子目录各有 `config.json`、`train_log.csv`、`test_metrics.json`、`test_metrics.csv`、`best.pt`、`last.pt`。
- 六份独立 `.log` 与 `queue_logs/professor_fpfcs_100epoch.log`：训练及队列运行记录。
- `queue.json`：运行状态、命令和源码/教师/划分 SHA-256。PID 为历史记录，不代表当前存活进程。
- `data/ISIC2018/paper_split_70_10_20_seed20260912.json`：锁定的图像 ID 划分。
- `PROFESSOR_FPFCS_100EPOCH_PROTOCOL_CN.md`：启动前制定的协议。
- `reproduction_code/`：本批训练/评估代码、src 模块、队列脚本、相关测试及 requirements.txt；`runtime_versions.json` 记录打包时环境与训练记录中的 PyTorch/CUDA/GPU。
- `FILE_INDEX.csv` 和 `MANIFEST.sha256`：包内文件索引、大小和逐文件 SHA-256。

checkpoint 内包含模型、优化器、调度器及 scaler 状态。best.pt 的模型状态对应最佳验证轮次；last.pt 为末轮记录。保存了训练状态不表示当前训练入口支持无缝续训。

本包不含原始图像、固定教师 checkpoint、虚拟环境和旧实验；教师与关键源码的校验值保存在 queue.json。

## 6. 复现方法

解压后进入 `reproduction_code/`。另行准备原始 ISIC2018 数据，放入 `data/ISIC2018/images/` 与 `data/ISIC2018/masks/`；将包内 `data/ISIC2018/paper_split_70_10_20_seed20260912.json` 复制到该代码目录中的相同相对位置。将原固定教师 checkpoint 放入 `formal_paper_seed42_v1/teacher_performance_context_seed42/best.pt`；用包内 queue.json 的对应 SHA-256 核验教师，避免换用不同教师。

创建 `.venv`，安装 requirements.txt，并确保使用可用的 CUDA 版 PyTorch。训练记录环境为 PyTorch 2.11.0+cu128、CUDA 12.8、RTX A5000；宽松依赖版本范围不能保证跨环境逐位一致。

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python run_professor_fpfcs_100epoch.py --prepare-only
.venv/bin/python run_professor_fpfcs_100epoch.py
```

在 reproduction_code 中运行会生成新的结果目录，包根目录中的已完成归档结果保持独立。队列不会覆盖非空的未完成目录，且用文件锁防止重复启动。

解压后在包根目录执行以下命令，可验证归档内容：

```bash
sha256sum -c MANIFEST.sha256
```
