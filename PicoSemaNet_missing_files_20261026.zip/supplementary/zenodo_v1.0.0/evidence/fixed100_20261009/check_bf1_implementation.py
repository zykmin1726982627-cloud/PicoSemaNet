"""Check the supplied GPU metric's semantics against the audited CPU metric."""
from pathlib import Path
import importlib.util, json, sys
import torch

ROOT=Path(__file__).resolve().parent
CODE=ROOT/'raw/unet_fpfcs_100epochs_3seeds_20261009/reproduction_code/src/metrics.py'
sys.path.insert(0,str(ROOT.parent/'bf1_euclidean_20261009'))
from bf1_euclidean import euclidean_boundary_f1_score
spec=importlib.util.spec_from_file_location('supplied_bf1_metrics',CODE)
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
torch.set_num_threads(2)
cases=[]
blank=torch.zeros(1,1,32,32,dtype=torch.bool)
full=torch.ones_like(blank)
cases.extend([(blank,blank),(full,full),(blank,full),(full,blank)])
base=blank.clone(); base[:,:,4:14,6:19]=True
for dx,dy in [(0,0),(1,0),(2,0),(2,2),(3,0),(8,8)]:
    cases.append((base,torch.roll(base,(dx,dy),(2,3))))
border=blank.clone(); border[:,:,0:10,0:10]=True
cases.extend([(border,base),(border,border),(border,blank)])
generator=torch.Generator().manual_seed(20261009)
for _ in range(20):
    cases.append((torch.rand(2,1,13,17,generator=generator)>.97,
                  torch.rand(2,1,13,17,generator=generator)>.97))
max_error=0
for left,right in cases:
    expected=euclidean_boundary_f1_score(left,right,reduction='none')
    actual=module.boundary_f1_score(left,right,distance='euclidean',tolerance=2,reduction='none')
    error=(expected-actual).abs().max().item()
    assert error<=1e-7
    max_error=max(max_error,error)
report={'status':'PASS','cases':len(cases),'max_absolute_error':max_error,
        'checks':'identical and empty masks, image borders, Euclidean axis/diagonal offsets, sparse random masks'}
(ROOT/'bf1_semantics_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report))
