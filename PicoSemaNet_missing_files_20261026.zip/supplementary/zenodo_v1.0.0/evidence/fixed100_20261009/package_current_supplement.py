"""Preserve historical evidence and append the audited EC-free configuration."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import statistics

WORK = Path(__file__).resolve().parent
PAPER = WORK.parent
EC = PAPER / 'ec_removal_20261009'
BF = PAPER / 'bf1_euclidean_20261009'
SOURCE = EC / 'Online_Resource_1_before.zip'
TARGET = PAPER / 'Online_Resource_1_reproducibility.zip'
PREFIX = 'current_configuration_20261009/'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

groups = {
    'PicoSemaNet (full), primary 200-epoch cap': [
        'formal_paper_ablation_supplement_v1/s3b_no_edge_seed42',
        'formal_paper_last30h_v1/no_edge_seed43',
        'formal_paper_last30h_v1/no_edge_seed44'],
    'No FPFCS (Seg+KD), primary seed 42': [
        'formal_paper_seed42_v1/ablation_a1_distill_only_seed42'],
    'PicoSemaNet (full) + EC, primary 200-epoch cap': [
        'formal_paper_seed42_v1/ablation_a7_no_deep_seed42',
        'formal_paper_multiseed_v1/ablation_a7_no_deep_seed43',
        'formal_paper_multiseed_v1/ablation_a7_no_deep_seed44'],
}
mapping = {}
for label, run_ids in groups.items():
    rows = []
    for run in run_ids:
        cfg = read_json(BF / 'baseline_source' / run / 'config.json')
        gpu = read_json(BF / 'baseline_source' / run / 'test_metrics.json')
        replay = read_json(BF / 'results' / run / 'metrics.json')
        rows.append(dict(run=run, seed=gpu['seed'], epochs_cap=cfg['epochs'],
                         epochs_completed=gpu['epochs_completed'],
                         patience=cfg['early_stopping_patience'],
                         best_epoch=gpu['best_epoch'], lambda_edge=cfg['lambda_edge'],
                         lambda_distill=cfg['lambda_distill'],
                         lambda_boundary=cfg['lambda_boundary'],
                         lambda_texture=cfg['lambda_texture'], lambda_sdf=cfg['lambda_sdf'],
                         dice_gpu=gpu['dice'], iou_gpu=gpu['iou'],
                         bf1_euclidean_cpu=replay['bf1_euclidean'],
                         checkpoint_sha256=replay['checkpoint_sha256']))
    mapping[label] = {'runs': rows, 'statistics_percentage': {
        metric: {'mean': statistics.mean(row[key] for row in rows)*100,
                 'sample_sd': statistics.stdev(row[key] for row in rows)*100 if len(rows)>1 else None}
        for metric, key in [('dice','dice_gpu'),('iou','iou_gpu'),('bf1','bf1_euclidean_cpu')]}}

mapping['fixed_100_epoch_comparison'] = read_json(WORK / 'audit.json')
mapping['notes'] = [
    'Final PicoSemaNet (full) = segmentation + FPFCS + KD; lambda_edge=0.',
    'Historical no_edge run identifiers are retained to preserve provenance.',
    'The +EC ablation is distinct from the final configuration.',
    'Other historical controls retaining EC do not isolate components of the final EC-free objective.',
    'Primary 200-epoch-cap statistics and fixed 100-epoch statistics must not be pooled.',
    'Historical BF1 was replayed on CPU; the six new runs report Euclidean BF1 directly on GPU.',
    'The three paired training seeds support descriptive differences, not a significance claim.'
]
(EC / 'configuration_mapping.json').write_text(json.dumps(mapping, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')

current_readme = '''UPDATE 2026-10-09: Final configuration and matched 100-epoch comparison.
PicoSemaNet (full) is Segmentation + FPFCS + KD, with EC weight zero.
EC is retained as the separate PicoSemaNet (full) + EC ablation.
current_configuration_20261009/configuration_mapping.json identifies the unchanged
historical run IDs now used for the primary EC-free model and the +EC ablation.
Primary EC-free runs: Dice 87.39 +/- 0.09%, IoU 79.88 +/- 0.13%,
Euclidean BF1 46.28 +/- 0.71%; maximum 200 epochs, patience 40.

fixed100_20261009/raw/ contains the original supplied experiment package,
including all six best and last checkpoints, configurations, 100-row training
logs, GPU test metrics, locked split, code, protocol, and source manifest.
Full FPFCS and No FPFCS each completed exactly 100 epochs at seeds 42,43,44.
Both groups use EC=0, KD=0.25, the same teacher and common hyperparameters.
Patience 101 prevents early stopping; the best-validation-Dice checkpoint is tested.
Full: Dice 87.35 +/- 0.02%, IoU 79.81 +/- 0.02%, BF1 45.81 +/- 0.64%.
No: Dice 87.14 +/- 0.13%, IoU 79.49 +/- 0.20%, BF1 45.25 +/- 0.93%.
These are means and sample SD over three training seeds, separate from primary results.
Mean paired gains: Dice +0.21, IoU +0.32, BF1 +0.55 percentage points.
BF1 declines by 0.05 points at seed 43. No statistical significance is claimed.
fixed100_20261009/audit.json records 180 successful artifact/protocol checks;
bf1_semantics_verification.json records 33 exact boundary-matching checks.

All pre-update code, configurations, metrics and logs remain byte-for-byte intact.
The pre-update README and checksum manifest are retained in history_20261009/.
Older statements below that checkpoints are omitted apply to historical runs;
the six new runs' checkpoints ARE included. Original ISIC images/masks remain omitted.
Figure sources and provenance for the EC-free primary checkpoint are in
current_configuration_20261009/figures and figure_generation. Drawing scripts
record the local audited generation environment; configure their data/weight
paths before replaying outside that environment. Historical primary weights
are identified by SHA-256 and are not included in this archive.
MANIFEST.sha256 verifies every other file in this updated archive.

--- Historical README, preserved below for context ---
'''

with ZipFile(SOURCE) as z:
    assert z.testzip() is None
    entries = {n: z.read(n) for n in z.namelist() if not n.endswith('/')}
historical = dict(entries)
entries['history_20261009/README.before_configuration_update.txt'] = entries['README.txt']
entries['history_20261009/MANIFEST.before_configuration_update.sha256'] = entries['MANIFEST.sha256']
entries['README.txt'] = current_readme.encode('utf-8') + entries['README.txt']
entries.pop('MANIFEST.sha256')

def add(path, archive_name):
    assert path.is_file(), path
    assert archive_name not in entries, archive_name
    entries[archive_name] = path.read_bytes()

add(EC / 'configuration_mapping.json', PREFIX + 'configuration_mapping.json')
for name in ['params_dice_comparison.pdf','picosemanet_deployment_path.pdf',
             'picosemanet_training_single_column.pdf','qualitative_comparison.pdf']:
    add(PAPER / name, PREFIX+'figures/'+name)
for name in ['params_dice_data.csv','params_dice_notes.md','gen_fig_params_dice.py',
             'figure1_data_check.json']:
    add(PAPER / 'figures' / name, PREFIX+'figures/'+name)
for name in ['draw_training.py','qualitative/manifest.json',
             'qualitative/inference_provenance.json','qualitative/per_example_metrics.csv',
             'qualitative/panel_alignment.json','qualitative/run_predictions.py',
             'qualitative/draw_comparison.py','deployment/draw_fig2.py']:
    add(EC / name, PREFIX+'figure_generation/'+name)
raw = WORK/'raw'/'unet_fpfcs_100epochs_3seeds_20261009'
for path in sorted(raw.rglob('*')):
    if path.is_file():
        add(path, 'fixed100_20261009/raw/'+path.relative_to(raw).as_posix())
for name in ['audit.json','audit_experiments.py','input_manifest.json','PROFESSOR_REQUIREMENTS_AUDIT_CN.md',
             'bf1_semantics_verification.json','check_bf1_implementation.py',
             'package_current_supplement.py']:
    add(WORK/name, 'fixed100_20261009/'+name)
entries['MANIFEST.sha256'] = ''.join(f'{sha(data)}  {name}\n' for name,data in sorted(entries.items())).encode('utf-8')
temp = TARGET.with_suffix('.pending.zip')
with ZipFile(temp, 'w', ZIP_DEFLATED, compresslevel=6) as z:
    for name,data in sorted(entries.items()):
        z.writestr(name,data)
with ZipFile(temp) as z:
    assert z.testzip() is None
    for line in z.read('MANIFEST.sha256').decode('utf-8').splitlines():
        digest,name = line.split('  ',1)
        assert sha(z.read(name)) == digest, name
    kept = 0
    for name,data in historical.items():
        if name not in ['README.txt','MANIFEST.sha256']:
            assert z.read(name) == data, name
            kept += 1
temp.replace(TARGET)
receipt = dict(status='PASS', historical_payloads_preserved=kept,
               total_files=len(entries), checksum_entries=len(entries)-1,
               size_bytes=TARGET.stat().st_size, sha256=sha(TARGET.read_bytes()),
               included_new_checkpoint_count=12, crc_and_sha256_verified=True)
(WORK/'supplement_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2))
