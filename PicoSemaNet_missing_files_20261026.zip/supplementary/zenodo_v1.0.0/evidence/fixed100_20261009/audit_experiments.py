"""Audit supplied artifacts without launching their training/queue scripts."""
from pathlib import Path, PurePosixPath
import csv, hashlib, json, math, statistics, sys
import torch

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT / 'raw' / 'unet_fpfcs_100epochs_3seeds_20261009'
RUNS = PACKAGE / 'formal_paper_professor_fpfcs_100ep_v1'
BASE = ROOT.parent / 'bf1_euclidean_20261009'
checks = []
def check(condition, label):
    if not condition:
        raise AssertionError(label)
    checks.append(label)
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
for line in (PACKAGE/'MANIFEST.sha256').read_text(encoding='utf-8').splitlines():
    checksum, name = line.split('  ', 1)
    check(digest(PACKAGE/name) == checksum, 'manifest:'+name)
queue = json.loads((RUNS/'queue.json').read_text())
for name, checksum in queue['sha256'].items():
    if name.startswith('formal_paper_seed42_v1/'):
        path = BASE / 'checkpoints' / name
    elif name.startswith('data/'):
        path = PACKAGE / name
    else:
        path = PACKAGE / 'reproduction_code' / name
    check(digest(path) == checksum, 'queue-input:'+name)
check(digest(PACKAGE/'data/ISIC2018/paper_split_70_10_20_seed20260912.json') ==
      digest(BASE/'baseline_source/data/ISIC2018/paper_split_70_10_20_seed20260912.json'), 'same-fixed-split')
for name in ['models.py','losses.py','dataset.py','utils.py']:
    check(digest(PACKAGE/'reproduction_code/src'/name) == digest(BASE/'baseline_source/src'/name), 'unchanged-source:'+name)
check(queue['status']=='completed' and len(queue['runs'])==6, 'six-completed-runs')
fields = ['model','base_channels','image_size','batch_size','epochs','early_stopping_patience',
          'learning_rate','weight_decay','min_learning_rate','scheduler_patience','scheduler_factor',
          'ema_decay','amp','aux_warmup_epochs','auxiliary_floor','max_aux_to_seg_ratio',
          'teacher_checkpoint','lambda_distill','distill_temperature','lambda_edge',
          'lambda_deep_supervision','max_deep_to_seg_ratio','lambda_shape','lambda_ambiguity',
          'boundary_distance','boundary_tolerance','threshold','splits_path',
          'max_test_samples','max_train_samples','max_val_samples','initial_checkpoint']
records, configs = [], {}
for entry in queue['runs']:
    name = entry['name']; group = entry['group']; seed = entry['seed']; folder = RUNS/name
    cfg = json.loads((folder/'config.json').read_text())
    metrics = json.loads((folder/'test_metrics.json').read_text())
    configs[name] = cfg
    check(entry['status']=='completed' and entry['returncode']==0, name+':normal-exit')
    check(seed == cfg['seed'] == metrics['seed'] and seed in [42,43,44], name+':seed')
    check(cfg['epochs']==cfg['epochs_completed']==metrics['epochs_completed']==100, name+':100-epochs')
    check(cfg['early_stopping_patience']==101, name+':no-early-stop')
    check(metrics['num_images']==520 and metrics['inference_parameters']==4844, name+':full-test-and-core')
    check(cfg['lambda_edge']==cfg['lambda_deep_supervision']==cfg['lambda_shape']==cfg['lambda_ambiguity']==0, name+':EC-DS-other-off')
    check(cfg['lambda_distill']==0.25 and cfg['distill_temperature']==2, name+':KD')
    expected = [0.18,0.05,0.12] if group=='full_fpfcs' else [0,0,0]
    check([cfg[k] for k in ['lambda_boundary','lambda_texture','lambda_sdf']]==expected, name+':FPFCS-weights')
    check(cfg['boundary_distance']==metrics['boundary_distance']=='euclidean' and
          cfg['boundary_tolerance']==metrics['boundary_tolerance']==2, name+':Euclidean-BF1')
    with (folder/'train_log.csv').open(newline='') as handle:
        epochs = list(csv.DictReader(handle))
    check([int(x['epoch']) for x in epochs]==list(range(1,101)), name+':100-log-rows')
    best = max(epochs, key=lambda x:float(x['val_dice']))
    check(int(best['epoch'])==metrics['best_epoch'] and
          math.isclose(float(best['val_dice']),metrics['best_val_dice'],abs_tol=1e-12), name+':best-validation-checkpoint')
    with torch.serialization.safe_globals([(PurePosixPath,'pathlib.PosixPath'), torch.torch_version.TorchVersion]):
        ckpt = torch.load(folder/'best.pt',map_location='cpu',weights_only=True)
        last = torch.load(folder/'last.pt',map_location='cpu',weights_only=True)
    check(ckpt['epoch']==metrics['best_epoch'] and last['epoch']==100, name+':checkpoint-epochs')
    check('model_state_dict' in ckpt and len(ckpt['model_state_dict'])>0, name+':weights-present')
    records.append({'run':name,'group':group,'seed':seed,'best_epoch':metrics['best_epoch'],
                    'epochs':100,'checkpoint_sha256':digest(folder/'best.pt'),
                    'best_val_dice':metrics['best_val_dice'],
                    **{k:metrics[k] for k in ['dice','iou','bf1','accuracy']}})
for seed in [42,43,44]:
    left=configs[f'full_fpfcs_seed{seed}']; right=configs[f'no_fpfcs_seed{seed}']
    check(all(left[k]==right[k] for k in fields), f'seed{seed}:matched-common-protocol')
summary = json.loads((RUNS/'summary.json').read_text())
groups={}
for group in ['full_fpfcs','no_fpfcs']:
    subset=[r for r in records if r['group']==group]
    check(len(subset)==3,group+':three-seeds')
    groups[group]={k:{'mean':statistics.mean(r[k] for r in subset),
                      'std':statistics.stdev(r[k] for r in subset)} for k in ['dice','iou','bf1','accuracy']}
    for k,stats in groups[group].items():
        for term in ['mean','std']:
            check(math.isclose(stats[term],summary['groups'][group]['metrics'][k][term],abs_tol=1e-13), group+':summary-'+k+'-'+term)
deltas=[]
for seed in [42,43,44]:
    left=next(r for r in records if r['group']=='full_fpfcs' and r['seed']==seed)
    right=next(r for r in records if r['group']=='no_fpfcs' and r['seed']==seed)
    deltas.append({'seed':seed,**{k:100*(left[k]-right[k]) for k in ['dice','iou','bf1','accuracy']}})
report={'status':'PASS','checks':checks,'records':records,'groups':groups,
        'paired_deltas_percentage_points':deltas,
        'paired_mean_percentage_points':{k:statistics.mean(r[k] for r in deltas) for k in ['dice','iou','bf1','accuracy']},
        'source':'supplied GPU artifacts; no new training or CPU replacement of reported scores',
        'inference':'small descriptive gains; no statistical significance claim'}
(ROOT/'audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:report[k] for k in ['status','groups','paired_deltas_percentage_points','paired_mean_percentage_points']},indent=2))
print('CHECKS PASSED:',len(checks))
