"""Direct color labels for the existing audited parameter--Dice data.

Literature coordinates and include/exclude decisions are preserved.
The PicoSemaNet point uses the final EC-free primary configuration (2026-10-09).
MambaLiteUNet SD = 0.24 was completed from the source Table 1 (2026-09-29).
Literature values use heterogeneous protocols; no controlled ranking is implied.
Project error bars are sample SD over seeds 42--44. Literature bars retain the
source-reported spread; the CSV records the provenance of every entry.
"""
import csv
import hashlib
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator, FuncFormatter

OUT = Path(__file__).resolve().parent
DATA = OUT / 'params_dice_data.csv'
with DATA.open(encoding='utf-8-sig', newline='') as f:
    all_rows = list(csv.DictReader(f))
rows = [r for r in all_rows if r['include'].lower() == 'true']
assert len(rows) == 17
assert all(float(r['params_m']) > 0 for r in rows), 'Log axis requires strictly positive parameter counts'
assert hashlib.sha256(DATA.read_bytes()).hexdigest().upper() == '888FF6997BAF2A1CDAD8B470DFBD30908A011824F8A58DB6FD826F373374BAFD'
plt.rcParams.update({
    'font.family': 'serif', 'font.serif': ['Times New Roman'],
    'font.size': 7, 'axes.labelsize': 8, 'axes.linewidth': .6,
    'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none',
    'savefig.facecolor': 'white', 'figure.facecolor': 'white',
})
# Fixed single-column canvas: 89 x 89 mm. No tight cropping of vector exports.
fig_width_mm = 89
fig_height_mm = 89
fig, ax = plt.subplots(figsize=(fig_width_mm/25.4, fig_height_mm/25.4), dpi=300)
fig.subplots_adjust(left=.107, right=.975, top=.91954, bottom=.203315)
gray, blue, red = '#66737D', '#356B8C', '#B43935'
model_colors = {
    'PicoSemaNet': '#C62728', 'MicroSemaNet': '#258B9B',
    'ContextUNet-3M': '#2E79AF', 'AULUNet-v3': '#25806D',
    'LB-UNet': '#80621F', 'EGE-UNet': '#BF4F83',
    'MALUNet': '#8960AF', 'TinyU-Net': '#768C20',
    'MambaLiteUNet': '#555C8E', 'U-Lite': '#418B79',
    'UNeXt': '#4264A3', 'Attention U-Net': '#447F52',
    'TransUNet': '#BB6527', 'U-Net++': '#B0801C',
    'U-Net': '#795387', 'SegNet': '#93604C',
    'DeepLabV3+': '#516B77',
}
ax.set_xscale('log')
ax.set_xlim(.0011, 230)
ax.set_ylim(86, 91.8)
ax.xaxis.set_major_locator(FixedLocator([.01, .1, 1, 10, 100]))
ax.xaxis.set_major_formatter(FuncFormatter(lambda x, p: f'{x:g}'))
ax.minorticks_off()
ax.set_yticks([86,87,88,89,90,91])
ax.set_xlabel('Parameters (M, log scale)', labelpad=6)
ax.set_ylabel('Dice (%)', labelpad=5)
ax.set_title('ISIC 2018', loc='left', fontsize=9, fontweight='bold', pad=10)
ax.set_axisbelow(True)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
for side in ['left','bottom']:
    ax.spines[side].set_color('#4E555B')
ax.tick_params(length=2.5, width=.6, pad=3, labelsize=6.5)

# Signed vertical offsets in points, measured from each error-bar endpoint.
# Every label stays horizontally centered on its own data point.
offsets = {
    'PicoSemaNet': -6, 'MicroSemaNet': 6, 'AULUNet-v3': 6,
    'LB-UNet': -6, 'EGE-UNet': 6, 'MALUNet': -6,
    'TinyU-Net': 6, 'MambaLiteUNet': 6, 'U-Lite': 6,
    'UNeXt': -6, 'ContextUNet-3M': 6, 'Attention U-Net': 6,
    'TransUNet': 6, 'U-Net++': 18, 'U-Net': -15,
    'SegNet': 6, 'DeepLabV3+': -12,
}
labels = []
for row in rows:
    name = row['model']
    x,y = float(row['params_m']), float(row['dice_percent'])
    ours = row['category']=='project_proposed'
    context = row['category']=='project_context'
    color = model_colors[name]
    marker = '*' if ours else 'D' if context else 'o'
    if row['dice_sd']:
        ax.errorbar(x,y,yerr=float(row['dice_sd']),fmt='none',
                    ecolor=color,elinewidth=.7,capsize=1.8,capthick=.7,zorder=3)
    ax.scatter(x,y,s=100 if ours else 23 if context else 15,
               marker=marker,c=color,edgecolors='white',linewidths=.35,zorder=4)
    label = 'PicoSemaNet (ours)\n4,844 parameters' if ours else name
    dy = offsets[name]
    sd = float(row['dice_sd']) if row['dice_sd'] else 0
    anchor_y = y + (sd if dy > 0 else -sd)
    labels.append(ax.annotate(label,xy=(x,anchor_y),xytext=(0,dy),
        textcoords='offset points',ha='center',va='bottom' if dy > 0 else 'top',
        color=color,fontsize=6.0 if ours else 5.8,fontweight='bold' if ours else 'normal',
        linespacing=1.15,
        zorder=5))

fig.legend(handles=[
    Line2D([],[],marker='o',markersize=3.8,color=gray,linestyle='',label='Literature'),
    Line2D([],[],marker='D',markersize=3.6,color=gray,linestyle='',label='Other project models'),
], loc='lower center',bbox_to_anchor=(.56,.005),ncol=2,
    frameon=False,fontsize=6.2,handletextpad=.35,columnspacing=1.4)
fig.canvas.draw()
renderer = fig.canvas.get_renderer()
overlaps=[]
for i, a in enumerate(labels):
    aa = matplotlib.text.Text.get_window_extent(a, renderer)
    for b in labels[i+1:]:
        bb = matplotlib.text.Text.get_window_extent(b, renderer)
        if aa.overlaps(bb): overlaps.append([a.get_text(),b.get_text()])
fig.savefig(OUT / 'params_dice_comparison.pdf')
fig.savefig(OUT / 'params_dice_comparison.svg')
fig.savefig(OUT / 'params_dice_comparison.png', dpi=600)
(OUT/'figure1_data_check.json').write_text(json.dumps({
    'source_csv_sha256':hashlib.sha256(DATA.read_bytes()).hexdigest(),
    'included_points':len(rows),'excluded_points':len(all_rows)-len(rows),
    'physical_dimensions_mm':[89,89],'central_values_altered':True,
    'revision':'PicoSemaNet full is Seg+FPFCS+KD (EC=0), using verified no_edge seeds 42-44',
    'source_spread_completed':{'MambaLiteUNet':0.24},
    'text_label_overlaps':overlaps,
    'model_colors':model_colors, 'label_leader_lines':False,
    'label_alignment':'Centered directly above or below each data point',
    'vertical_offsets_pt':offsets,
    'panel_alignment':'Not applicable: one standalone scatter plot.',
    'caveat':'Literature evaluation protocols differ. Error bars retain source-reported spreads.',
},indent=2),encoding='utf-8')
print(json.dumps({'included_points':len(rows),'text_label_overlaps':overlaps}))
