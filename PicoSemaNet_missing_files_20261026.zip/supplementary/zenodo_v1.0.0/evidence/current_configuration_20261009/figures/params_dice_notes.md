# Figure 1 data provenance

Updated 2026-10-09: the PicoSemaNet point now represents the final Seg+FPFCS+KD configuration, with EC weight zero. Its primary 200-epoch-cap runs at seeds 42-44 give 87.39056% mean Dice and 0.08764 percentage-point sample SD (plotted as 87.39 +/- 0.09). The run identifiers are `formal_paper_ablation_supplement_v1/s3b_no_edge_seed42`, `formal_paper_last30h_v1/no_edge_seed43`, and `formal_paper_last30h_v1/no_edge_seed44`. The original GPU Dice values are used; all literature coordinates remain unchanged. The separate fixed 100-epoch comparison is reported in Table 3 and is not the source of this point.

Updated 2026-09-29 after checking the original source tables for all 14 included literature pairs. Parameter counts and Dice centers are unchanged. MambaLiteUNet now includes the reported SD of 0.24 percentage points (five runs; mean Dice 91.07%).

The CSV records source URLs, table numbers, PDF page numbers, reporting context, spread definitions and run counts where explicit. Empty fields mean not established in this audit, not zero. The legacy `dice_sd` column stores the plotted spread; consult `spread_type` before interpreting a literature bar as SD.

These are heterogeneous literature protocols, not a controlled ranking. Nine baseline pairs are results reported by later papers, not necessarily each model's original paper. TinyU-Net Table 1 contributes lesion Dice, not the foreground/background mean. MambaLiteUNet uses the 256x256 setting, not its 320x320 row.

## Sources

- EGE: https://arxiv.org/pdf/2307.08473 (Table 1, ISIC2018 block; PDF page 7).

- Tiny: https://papers.miccai.org/miccai-2024/paper/2191_paper.pdf (Table 1, Dice / Lesion column; PDF page 7).

- LB: https://papers.miccai.org/miccai-2024/paper/2135_paper.pdf (Table 1, ISIC2018 block; PDF page 8).

- AUL: https://bmva-archive.org.uk/bmvc/2025/assets/papers/Paper_1199/paper.pdf (Table 1, ISIC2018 / AULUNet-v3 row; PDF page 7).

- Mamba: https://openaccess.thecvf.com/content/CVPR2026/papers/Rahman_MambaLiteUNet_Cross-Gated_Adaptive_Feature_Fusion_for_Robust_Skin_Lesion_Segmentation_CVPR_2026_paper.pdf (Table 1 Dice and SD; Table 4 parameters; Tables 7-10 confirm same full configuration; PDF page 5).

EGE-UNet and MambaLiteUNet explicitly report SD. The LB-UNet and AULUNet +/- values are preserved as reported spread; their exact spread definitions were not explicit in the main text checked. Project bars are sample SD across seeds 42-44.
