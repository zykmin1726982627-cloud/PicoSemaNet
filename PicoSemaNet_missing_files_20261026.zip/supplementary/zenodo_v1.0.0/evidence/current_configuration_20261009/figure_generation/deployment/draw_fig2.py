"""A code-faithful schematic with an official image and actual model inference.

Contract: show the 4,844-parameter inference graph, separate training-only
channel supervision, and illustrate the input/output with a prespecified test
example. Schematic-led composite; no performance claim from one example.
180 x 90 mm. Clinical source images are only resized, without color editing.
"""
from pathlib import Path
import sys, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch
from PIL import Image

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,r'C:\Users\19866\.codex\plotting-skill-sources\nature-skills\skills\nature-figure\scripts')
from audit_panel_alignment import require_matplotlib_panel_alignment

plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman'],
    'font.size':7.5,'pdf.fonttype':42,'svg.fonttype':'none',
    'mathtext.fontset':'stix','axes.linewidth':.6})
W,H=180,90
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white')
ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,W),ylim=(0,H));ax.axis('off')
ink='#273340';muted='#5b6772';edge='#697782'
enc='#e6eee8';dec='#e5edf6';bottle='#ece8f1'

def txt(x,y,s,size=7.5,weight='normal',color=ink,ha='center',**kw):
    return ax.text(x,y,s,fontsize=size,fontweight=weight,color=color,
                   ha=ha,va='center',zorder=6,**kw)

def box(x,y,w,h,label,fill='white',size=7.5):
    ax.add_patch(Rectangle((x,y),w,h,facecolor=fill,edgecolor=edge,lw=.65,zorder=3))
    txt(x+w/2,y+h/2,label,size)

def arrow(points,color=ink,lw=.75):
    for a,b in zip(points[:-2],points[1:-1]):
        ax.plot([a[0],b[0]],[a[1],b[1]],color=color,lw=lw,zorder=2)
    ax.add_patch(FancyArrowPatch(points[-2],points[-1],arrowstyle='-|>',
        mutation_scale=6.2,lw=lw,color=color,shrinkA=0,shrinkB=.5,zorder=2))

def stage(x,cy,name,res,c,fill):
    w,h=25,10
    ax.add_patch(Rectangle((x,cy-h/2),w,h,facecolor=fill,edgecolor=edge,lw=.7,zorder=3))
    txt(x+w/2,cy+1.65,name,8.4,'bold')
    txt(x+w/2,cy-1.7,f'{res} × {res}  |  C = {c}',6.9)

def raster(path,x,y,size):
    ar=np.asarray(Image.open(ROOT/'assets'/path))
    ax.imshow(ar,cmap='gray' if ar.ndim==2 else None,vmin=0 if ar.ndim==2 else None,
              vmax=255 if ar.ndim==2 else None,extent=[x,x+size,y,y+size],
              interpolation='nearest',zorder=3,aspect='equal')
    ax.add_patch(Rectangle((x,y),size,size,fill=False,edgecolor=edge,lw=.6,zorder=4))

txt(3,86,'PicoSemaNet (full)',12,'bold',ha='left')
txt(177,86,'4,844 inference parameters',10,'bold',ha='right')
txt(50.5,77,'Encoder',8.8,'bold')
txt(123.5,77,'Decoder',8.8,'bold')
txt(87,73,'Gated skip connections',8,color=muted)

ys=[64,49,34,19]
for i,(cy,r,c) in enumerate(zip(ys,[320,160,80,40],[4,7,9,11])):
    stage(38,cy,f'E{i+1}',r,c,enc)
    stage(111,cy,f'D{i+1}',r,c,dec)
    arrow([(63,cy),(80,cy)],color='#81909c',lw=.65)
    box(80,cy-2.8,14,5.6,'Gate',fill='#f5f7f8',size=7.5)
    arrow([(94,cy),(111,cy)],color='#81909c',lw=.65)
    if i<3:
        arrow([(50.5,cy-5),(50.5,ys[i+1]+5)])
        arrow([(123.5,ys[i+1]+5),(123.5,cy-5)])
stage(74.5,8,'B',20,12,bottle)
arrow([(50.5,14),(50.5,8),(74.5,8)])
arrow([(99.5,8),(123.5,8),(123.5,14)])

raster('input_320.png',3,53,22)
txt(14,78,'Input image',7.5,'bold')
arrow([(25,64),(38,64)])
txt(31.5,69.2,'3 × 3\nstem',7.2)
raster('ground_truth_320.png',3,19,22)
txt(14,15.8,'Reference mask',7.1,'bold')

box(145,60,32,8,'1 × 1 head',fill='#f0f2f4')
arrow([(136,64),(145,64)])
box(145,45,32,8,'Residual refinement',fill='#f0f2f4',size=7.1)
arrow([(161,60),(161,53)])
arrow([(140,64),(140,49),(145,49)])
ax.plot(140,64,'o',ms=2,color=ink,zorder=5)
raster('prediction_seed42.png',150,19,22)
arrow([(161,45),(161,41)])
txt(161,15.8,'Model prediction',7.2,'bold')

fig.canvas.draw()
require_matplotlib_panel_alignment(fig,json_out=str(ROOT/'fig2_alignment.json'),
    overlay_svg=str(ROOT/'fig2_alignment.svg'),strict=True,tolerance_pt=1.5)
for ext in ['pdf','svg','png']:
    fig.savefig(ROOT/f'picosemanet_deployment_path_real.{ext}',dpi=450)
plt.close(fig)
(ROOT/'caption.txt').write_text('PicoSemaNet deployment graph with 4,844 parameters. Stage labels specify spatial resolution and channel count C; B denotes the bottleneck. The example is ISIC_0000013 from the fixed internal test split of ISIC 2018. The prediction is obtained from the seed-42 checkpoint with a probability threshold of 0.5. The reference mask is shown for comparison and is not a network input.\n')
(ROOT/'method_details.txt').write_text('Details retained outside the figure for later manuscript insertion (do not duplicate if already stated):\n\nEncoder and decoder stages use depthwise-separable residual blocks. The encoder downsamples features by 2 x 2 max pooling; the decoder uses bilinear upsampling. Gated skip features are concatenated with the upsampled features before 1 x 1 fusion. The bottleneck uses depthwise context branches with dilation rates 1, 2, and 4. The segmentation head produces coarse logits, which are refined by a residual correction from the final decoder feature. Structural supervision of channels 0-2 is used only during training and introduces no deployed branches.\n\nExample provenance: the first sample in the fixed internal test split was selected before inference. The image and reference mask were obtained from the official ISIC 2018 archive. This single example illustrates the graph; it is not a summary of test-set performance.\n')
print(ROOT/'picosemanet_deployment_path_real.pdf')
