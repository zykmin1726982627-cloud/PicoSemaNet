"""Real test images and checkpoint predictions; no mask retouching.

Question: how do the fixed seed-42 models delineate the same four lesions?
Selection: first four test-list entries, fixed before inference.
Design: 4 x 6 equal square panels, black/white masks, 180 mm wide.
"""
from pathlib import Path
import sys, json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,r'C:\Users\19866\.codex\plotting-skill-sources\nature-skills\skills\nature-figure\scripts')
from audit_panel_alignment import require_matplotlib_panel_alignment

manifest=json.loads((ROOT/'manifest.json').read_text())
plt.rcParams.update({'font.family':'Times New Roman','font.size':8,
                     'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none'})
width=180; panel=27.3; gap=1.5; left=7; bottom=1.5
height=4*panel+3*gap+bottom+8
fig=plt.figure(figsize=(width/25.4,height/25.4),facecolor='white')
axes=[]
headers=['Image','Ground truth','U-Net','Seg only','No FPFCS','PicoSemaNet (full)']
for row,sample in enumerate(manifest['sample_ids']):
    paths=[ROOT/'assets'/f'{sample}_input320.png',ROOT/'assets'/f'{sample}_gt320.png']
    paths += [ROOT/'predictions'/f'{sample}_{model}.png' for model in manifest['runs']]
    y=bottom+(3-row)*(panel+gap)
    fig.text(2.5/width,(y+panel/2)/height,f'({chr(97+row)})',ha='center',va='center',fontsize=8)
    for col,path in enumerate(paths):
        x=left+col*(panel+gap)
        ax=fig.add_axes([x/width,y/height,panel/width,panel/height])
        ax.imshow(Image.open(path),cmap='gray',vmin=0,vmax=255,interpolation='nearest')
        ax.set_axis_off(); axes.append(ax)
        if row==0:
            fig.text((x+panel/2)/width,(y+panel+2.2)/height,headers[col],
                     ha='center',va='bottom',fontsize=7.5 if col==5 else 8,
                     fontweight='bold' if col==5 else 'normal')
fig.canvas.draw()
require_matplotlib_panel_alignment(fig,axes=axes,
    panel_ids=[f'r{r}c{c}' for r in range(4) for c in range(6)],
    row_groups=[[f'r{r}c{c}' for c in range(6)] for r in range(4)],
    column_groups=[[f'r{r}c{c}' for r in range(4)] for c in range(6)],
    json_out=ROOT/'panel_alignment.json')
for ext in ['pdf','svg','png']:
    fig.savefig(ROOT/f'qualitative_comparison.{ext}',dpi=300,facecolor='white')
plt.close(fig)
print('Exported qualitative_comparison.pdf/.svg/.png')
