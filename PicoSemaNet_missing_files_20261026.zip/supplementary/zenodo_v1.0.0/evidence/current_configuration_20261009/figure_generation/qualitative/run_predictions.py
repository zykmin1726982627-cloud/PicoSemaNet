from pathlib import Path, PurePosixPath
import sys, json, hashlib, csv
import numpy as np
from PIL import Image
import torch

root=Path(__file__).resolve().parent
baseline=root.parent.parent/'bf1_euclidean_20261009'/'baseline_source'
checkpoints=root.parent.parent/'bf1_euclidean_20261009'/'checkpoints'
sys.path.insert(0,str(baseline))
from src.models import build_model

manifest=json.loads((root/'manifest.json').read_text())
assets=root/'assets'; output=root/'predictions'; output.mkdir(exist_ok=True)
inputs=[]; truth=[]
for sample in manifest['sample_ids']:
    im=Image.open(assets/(sample+'.jpg')).convert('RGB').resize((320,320),Image.Resampling.BILINEAR)
    gt=Image.open(assets/(sample+'_segmentation.png')).convert('L').resize((320,320),Image.Resampling.NEAREST)
    im.save(assets/(sample+'_input320.png'))
    mask=np.asarray(gt)>0
    Image.fromarray(mask.astype(np.uint8)*255).save(assets/(sample+'_gt320.png'))
    inputs.append(torch.from_numpy(np.asarray(im,dtype=np.float32)/255).permute(2,0,1))
    truth.append(mask)
x=(torch.stack(inputs)-.5)/.5
torch.set_num_threads(2)
metrics=[]; provenance=[]
for name,run in manifest['runs'].items():
    folder=baseline/run
    weights=checkpoints/run/'best.pt'
    cfg=json.loads((folder/'config.json').read_text())
    assert cfg['seed']==42 and cfg['image_size']==320
    assert cfg['splits_path']=='data/ISIC2018/paper_split_70_10_20_seed20260912.json'
    with torch.serialization.safe_globals([(PurePosixPath,'pathlib.PosixPath'),torch.torch_version.TorchVersion]):
        ckpt=torch.load(weights,map_location='cpu',weights_only=True)
    model=build_model(cfg['model'],base_channels=cfg['base_channels'])
    model.load_state_dict(ckpt['model_state_dict'],strict=True)
    model.eval()
    with torch.inference_mode():
        result=model(x)
        logits=result['seg_logits'] if isinstance(result,dict) else result
        probs=logits.sigmoid().numpy()[:,0]
    for sample,prob,gt in zip(manifest['sample_ids'],probs,truth):
        pred=prob>=.5
        Image.fromarray(pred.astype(np.uint8)*255).save(output/f'{sample}_{name}.png')
        np.save(output/f'{sample}_{name}_prob.npy',prob)
        tp=(pred&gt).sum(); fp=(pred&~gt).sum(); fn=(~pred&gt).sum()
        row=dict(sample=sample,model=name,dice=float(2*tp/(2*tp+fp+fn)),iou=float(tp/(tp+fp+fn)),false_positive_pixels=int(fp),false_negative_pixels=int(fn))
        metrics.append(row);print(row,flush=True)
    provenance.append(dict(name=name,run=run,model=cfg['model'],base_channels=cfg['base_channels'],seed=cfg['seed'],epoch=ckpt.get('epoch'),parameters=cfg['inference_parameters'],checkpoint_sha256=hashlib.sha256((weights).read_bytes()).hexdigest()))
with (root/'per_example_metrics.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(metrics[0]));w.writeheader();w.writerows(metrics)
(root/'inference_provenance.json').write_text(json.dumps(dict(models=provenance,torch_version=torch.__version__,threshold=.5,preprocessing='PIL RGB bilinear 320x320; (x/255-0.5)/0.5; nearest-neighbor masks >0',evaluation='model_state_dict; strict load; eval; no augmentation or mask postprocessing',sample_selection=manifest['selection']),indent=2))
