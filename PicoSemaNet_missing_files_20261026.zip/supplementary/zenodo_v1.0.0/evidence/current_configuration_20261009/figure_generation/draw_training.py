from pathlib import Path
import shutil
WORK=Path(__file__).resolve().parent
PAPER=WORK.parent
FIGURES=PAPER/'figures'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
plt.rcParams.update({'font.family':'Times New Roman', 'font.size':23,
                     'pdf.fonttype':42, 'mathtext.fontset':'stix'})
fig = plt.figure(figsize=(980/100, 1030/100))
ax = fig.add_axes([0,0,1,1])
ax.set(xlim=(0,980), ylim=(1030,0)); ax.axis('off')
def box(x,y,w,h,fill,stroke,rounding=12):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle=f'round,pad=0,rounding_size={rounding}',
                              facecolor=fill,edgecolor=stroke,linewidth=2))
def text(x,y,label,size=23,color='#111827',weight='normal'):
    ax.text(x,y,label,fontsize=size,ha='center',va='center',color=color,fontweight=weight)
def arrow(points):
    for p,q in zip(points[:-2],points[1:-1]):
        ax.plot([p[0],q[0]],[p[1],q[1]],color='#26384D',lw=2)
    ax.add_patch(FancyArrowPatch(points[-2],points[-1],arrowstyle='-|>',mutation_scale=15,
                               color='#26384D',linewidth=2))
box(24,22,932,986,'white','#5277A0',22)
box(42,43,230,48,'#FBECEC','#B84A4A',24)
text(157,67,'Training only',23,weight='bold')
text(621,67,'Fixed-channel supervision',28,weight='bold')
text(490,132,'Applied at E1-E4, B, and D4-D1',23,color='#425466')
for y,color,fill,ch,role,target,loss in [
    (172,'#B84A4A','#FBECEC','ch. 0','Boundary','Mask-derived Sobel target',r'$\mathcal{L}_b$'),
    (344,'#B47A18','#FFF4D8','ch. 1','Texture energy','Image + mask target',r'$\mathcal{L}_t$'),
    (516,'#23877F','#E8F4F2','ch. 2','Distance proxy','Mask-derived morph. target',r'$\mathcal{L}_d$')]:
    box(34,y,912,138,'white',color,17)
    box(52,y+28,126,82,fill,color); text(115,y+69,ch,25,weight='bold')
    arrow([(190,y+69),(220,y+69),(220,y+39),(238,y+39)])
    box(244,y+12,406,55,'#F2F6FA','#5277A0')
    text(447,y+28,'GN + affine',20); text(447,y+52,role+' prediction',20)
    box(244,y+81,406,43,fill,color); text(447,y+103,target,20)
    arrow([(661,y+39),(850,y+39),(850,y+55),(882,y+55)])
    arrow([(661,y+102),(850,y+102),(850,y+83),(882,y+83)])
    box(888,y+31,42,76,fill,color,10); text(909,y+69,loss,22)
arrow([(909,654),(909,704),(490,704),(490,730)])
box(72,736,836,78,'#F8FAFC','#64748B')
text(490,775,r'$\mathcal{L}_{\mathrm{FPFCS}}^{\mathrm{raw}}=0.18\mathcal{L}_b+0.05\mathcal{L}_t+0.12\mathcal{L}_d$',25)
arrow([(490,816),(490,844)])
box(54,850,872,82,'#E8F0F7','#5277A0')
text(490,877,r'$\mathcal{L}_{\mathrm{total}}=\mathcal{L}_{\mathrm{seg}}+\alpha_e c_{\mathrm{FPFCS}}\mathcal{L}_{\mathrm{FPFCS}}^{\mathrm{raw}}$',25)
text(490,909,r'$+\,0.25\mathcal{L}_{\mathrm{KD}}$',25)
box(72,948,836,43,'#FBECEC','#B84A4A',21)
text(490,969,'Readouts and teacher removed after training',22,weight='bold')
for ext in ['pdf','svg','png']:
    fig.savefig(WORK / f'picosemanet_training_single_column.{ext}',dpi=200)
plt.close(fig)
shutil.copy2(WORK/'picosemanet_training_single_column.pdf', PAPER/'picosemanet_training_single_column.pdf')
for name in ['picosemanet_training_single_column.pdf','picosemanet_deployment_path.pdf']:
    shutil.copy2(PAPER/name, FIGURES/name)
print('EC-free figures regenerated; historical evidence unchanged.')
