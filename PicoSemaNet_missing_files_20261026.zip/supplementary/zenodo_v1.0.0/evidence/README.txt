UPDATE 2026-10-09: Final configuration and matched 100-epoch comparison.
PicoSemaNet (full) is Segmentation + FPFCS + KD, with EC weight zero.
EC is retained as the separate PicoSemaNet (full) + EC ablation.
current_configuration_20261009/configuration_mapping.json identifies the unchanged
historical run IDs now used for the primary EC-free model and the +EC ablation.
Primary EC-free runs: Dice 87.39 +/- 0.09%, IoU 79.88 +/- 0.13%,
Euclidean BF1 46.28 +/- 0.71%; maximum 200 epochs, patience 40.

fixed100_20261009/raw/ contains the original supplied experiment package,
including all six best and last checkpoints, configurations, 100-row training
logs, GPU test metrics, locked split, code, protocol, and source manifest.
Full FPFCS and No FPFCS each completed exactly 100 epochs at seeds 42,43,44.
Both groups use EC=0, KD=0.25, the same teacher and common hyperparameters.
Patience 101 prevents early stopping; the best-validation-Dice checkpoint is tested.
Full: Dice 87.35 +/- 0.02%, IoU 79.81 +/- 0.02%, BF1 45.81 +/- 0.64%.
No: Dice 87.14 +/- 0.13%, IoU 79.49 +/- 0.20%, BF1 45.25 +/- 0.93%.
These are means and sample SD over three training seeds, separate from primary results.
Mean paired gains: Dice +0.21, IoU +0.32, BF1 +0.55 percentage points.
BF1 declines by 0.05 points at seed 43. No statistical significance is claimed.
fixed100_20261009/audit.json records 180 successful artifact/protocol checks;
bf1_semantics_verification.json records 33 exact boundary-matching checks.

All pre-update code, configurations, metrics and logs remain byte-for-byte intact.
The pre-update README and checksum manifest are retained in history_20261009/.
Older statements below that checkpoints are omitted apply to historical runs;
the six new runs' checkpoints ARE included. Original ISIC images/masks remain omitted.
Figure sources and provenance for the EC-free primary checkpoint are in
current_configuration_20261009/figures and figure_generation. Drawing scripts
record the local audited generation environment; configure their data/weight
paths before replaying outside that environment. Historical primary weights
are identified by SHA-256 and are not included in this archive.
MANIFEST.sha256 verifies every other file in this updated archive.

--- Historical README, preserved below for context ---
UPDATE 2026-10-09: The paper now reports Euclidean BF1.
The legacy src/metrics.py and original result files use square-tolerance BF1
and are preserved unchanged as historical evidence.
Use bf1_euclidean_20261009/bf1_euclidean.py and reevaluate.py for the new metric.
That directory includes all 47 CPU reevaluations, per-image metric records,
the table mapping, checkpoint hashes, official-data manifest, and verification.
Training checkpoints and original Dice/IoU are unchanged. CPU/GPU replay
differences are recorded separately. Model weights and ISIC images are omitted.

Online Resource 1: Reproducibility files

Article: Full-Path Fixed-Channel Supervision for Extremely Lightweight Skin Lesion Segmentation

This archive contains training and evaluation code, the fixed split identifiers,
per-run configurations and test metrics, training logs for the 14 runs added on
2026-09-24, three-seed result summaries, per-image bootstrap inputs, and
bootstrap outputs. The new runs complete seeds 43 and 44 for the conventional
U-Net and equal-parameter U-Net baselines and for the no-KD, no-EC, no-boundary,
no-texture, and no-distance controls. Their seed-42 artifacts were already in
the earlier archive and remain here.

The new runs came from UNET_last30h_new_results_20260924.zip
SHA-256: 5688ca092700b9687bd8652dee1dad41e4c87332293258b67309778e4a6f2d38

The ISIC 2018 images and masks and model checkpoints are not redistributed.
MANIFEST.sha256 verifies every other file in this archive.
Verification update 2026-09-28: qualitative_replay/ contains figure provenance and CPU per-image measurements, kept separate from the original GPU records. verification_20260928/ contains a forward-hook parameter/MAC recount and script.
