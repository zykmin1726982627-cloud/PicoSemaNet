# License scope and third-party notices

The authors approved the following release licensing on 2026-10-25.

- Original software and associated software documentation: MIT, see LICENSE-CODE.txt.
- Author-created experiment records, figures, and model checkpoints: Creative Commons Attribution 4.0 International (CC BY 4.0), see LICENSE-DATA.txt and https://creativecommons.org/licenses/by/4.0/.
- Third-party code, dependencies, and materials retain their existing copyright and license terms; neither license above overrides them.

Attribute the materials to Yikuan Zheng, Bohe Fan, and Gaurav Gupta and cite this specific release DOI. The material category, rather than the archive subdirectory, determines its license. Original notices remain applicable inside the immutable evidence unit.

Third-party Python dependencies are not bundled. ISIC source images and masks are not bundled and remain subject to their official access and reuse conditions. Scientific references and original dataset identifiers do not transfer rights to the underlying source publications or images.

The licensing scope is declared here so the original evidence files and historical manifests do not need to be rewritten. The new release manifest authenticates the complete distribution.
