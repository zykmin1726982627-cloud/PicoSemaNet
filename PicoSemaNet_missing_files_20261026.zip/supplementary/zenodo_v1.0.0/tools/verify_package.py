"""Verify the exact release files without loading checkpoint pickle data."""
from pathlib import Path
import hashlib
import sys

ROOT = Path(__file__).resolve().parents[1]

def verify(base, manifest):
    count = 0
    for line in manifest.read_text(encoding="utf8").splitlines():
        if not line.strip():
            continue
        expected, name = line.split("  ", 1)
        path = (base / name).resolve()
        if not path.is_relative_to(base.resolve()):
            raise ValueError("Path escapes package: " + name)
        with path.open("rb") as handle:
            actual = hashlib.file_digest(handle, "sha256").hexdigest()
        if actual != expected:
            raise ValueError("Checksum mismatch: " + name)
        count += 1
    return count

def main():
    released = verify(ROOT, ROOT / "MANIFEST.sha256")
    archived = verify(ROOT / "evidence", ROOT / "evidence" / "MANIFEST.sha256")
    print(f"PASS: {released} release files; {archived} original evidence files")

if __name__ == "__main__":
    main()
