"""Prepare or run the six archived matched commands with portable paths."""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import shlex
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "evidence/fixed100_20261009/raw"
CODE = RAW / "reproduction_code"
QUEUE = RAW / "formal_paper_professor_fpfcs_100ep_v1/queue.json"
TEACHER_NAME = "formal_paper_seed42_v1/teacher_performance_context_seed42/best.pt"

def replace(command, flag, value):
    index = command.index(flag) + 1
    command[index] = str(value)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--num-workers", type=int, default=8)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--dry-run", action="store_true")
    action.add_argument("--run", action="store_true")
    args = parser.parse_args()
    output = args.output_dir.resolve()
    if output.is_relative_to((ROOT / "evidence").resolve()) or output.is_relative_to((ROOT / "checkpoints").resolve()):
        parser.error("output must be outside archived files")
    if output.exists() and any(output.iterdir()):
        parser.error("output directory must be empty; choose a new directory")
    queue = json.loads(QUEUE.read_text(encoding="utf8"))
    teacher = ROOT / "checkpoints" / TEACHER_NAME
    expected = queue["sha256"][TEACHER_NAME]
    with teacher.open("rb") as handle:
        if hashlib.file_digest(handle, "sha256").hexdigest() != expected:
            raise ValueError("Shared teacher checkpoint hash mismatch")
    split = ROOT / "evidence/data/ISIC2018/paper_split_70_10_20_seed20260912.json"
    data = args.data_root.resolve()
    ids = json.loads(split.read_text(encoding="utf8"))
    missing = []
    for subset in ("train", "val", "test"):
        for image_id in ids[subset]:
            for path in (data / "images" / f"{image_id}.jpg",
                         data / "masks" / f"{image_id}_segmentation.png"):
                if not path.is_file():
                    missing.append(str(path))
    if missing and args.run:
        raise FileNotFoundError(f"{len(missing)} required image/mask files absent; first: {missing[0]}")
    plan = []
    for entry in queue["runs"]:
        command = copy.copy(entry["command"])
        command[0] = sys.executable
        command[2] = str(CODE / "train.py")
        for flag, value in {
            "--data-root": data, "--splits-path": split,
            "--output-dir": output / entry["name"],
            "--teacher-checkpoint": teacher, "--device": args.device,
            "--num-workers": args.num_workers,
        }.items():
            replace(command, flag, value)
        plan.append({"name": entry["name"], "group": entry["group"],
                     "seed": entry["seed"], "command": command})
    output.mkdir(parents=True, exist_ok=True)
    (output / "launch_plan.json").write_text(json.dumps({
        "source_queue": str(QUEUE.relative_to(ROOT)),
        "teacher_sha256": expected, "missing_dataset_files": len(missing),
        "executed": bool(args.run), "runs": plan,
    }, indent=2), encoding="utf8")
    for entry in plan:
        print(shlex.join(entry["command"]), flush=True)
        if args.run:
            subprocess.run(entry["command"], cwd=CODE, check=True)
    if args.dry_run:
        print(f"DRY RUN ONLY: no training started; {len(missing)} image/mask files missing.")

if __name__ == "__main__":
    main()
