"""CPU replay using original model/metric code and the fixed internal test IDs."""
from pathlib import Path
import argparse
import csv
import hashlib
import importlib.util
import json
import platform
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence"
CODE = EVIDENCE / "bf1_euclidean_20261009"

def inventory():
    original = json.loads((CODE / "run_manifest.json").read_text(encoding="utf8"))
    runs = {}
    for row in original["runs"]:
        item = dict(row)
        item["checkpoint"] = str(ROOT / "checkpoints" / row["run"] / "best.pt")
        runs[row["run"]] = item
    fixed = EVIDENCE / "fixed100_20261009/raw/formal_paper_professor_fpfcs_100ep_v1"
    for group in ("full_fpfcs", "no_fpfcs"):
        for seed in (42, 43, 44):
            name = f"{group}_seed{seed}"
            folder = fixed / name
            config = json.loads((folder / "config.json").read_text(encoding="utf8"))
            metrics = json.loads((folder / "test_metrics.json").read_text(encoding="utf8"))
            path = folder / "best.pt"
            # Hash comes from the archived original manifest, rather than a newly trusted digest.
            rel = path.relative_to(EVIDENCE).as_posix()
            entries = dict((line.split("  ", 1)[1], line.split("  ", 1)[0])
                           for line in (EVIDENCE / "MANIFEST.sha256").read_text().splitlines())
            key = "fixed100/" + name
            runs[key] = {"run": key, "group": group, "seed": seed,
                         "model": config["model"], "checkpoint": str(path),
                         "checkpoint_sha256": entries[rel], "original_metrics": metrics}
    return runs

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--list", action="store_true")
    parser.add_argument("--run")
    parser.add_argument("--dataset-root", type=Path)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--batch-size", type=int, default=8)
    args = parser.parse_args()
    runs = inventory()
    if args.list:
        print("\n".join(runs))
        return
    if args.run not in runs or args.dataset_root is None or args.output_dir is None:
        parser.error("provide a listed --run, --dataset-root and --output-dir")
    if args.limit < 0 or args.threads < 1 or args.batch_size < 1:
        parser.error("limit must be nonnegative; threads and batch-size must be positive")
    output = args.output_dir.resolve()
    if output.is_relative_to(EVIDENCE.resolve()) or output.is_relative_to((ROOT / "checkpoints").resolve()):
        parser.error("output must be outside archived evidence and checkpoints")
    if output.exists() and any(output.iterdir()):
        parser.error("output directory must be empty")
    sys.path.insert(0, str(CODE))
    spec = importlib.util.spec_from_file_location("archived_cpu_replay", CODE / "reevaluate.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.torch.set_num_threads(args.threads)
    split_path = EVIDENCE / "data/ISIC2018/paper_split_70_10_20_seed20260912.json"
    ids = json.loads(split_path.read_text(encoding="utf8"))["test"]
    if len(ids) != 520:
        raise ValueError("Unexpected locked test split")
    ids = ids[:args.limit] if args.limit else ids
    x, y = module.preload(ids, False, args.dataset_root)
    row = runs[args.run]
    model, metadata = module.load(row)
    records = []
    with module.torch.inference_mode():
        for offset in range(0, len(ids), args.batch_size):
            target = y[offset:offset + args.batch_size]
            logits = model(x[offset:offset + args.batch_size], return_aux=False)["seg_logits"]
            prediction = logits.sigmoid() >= 0.5
            values = {
                "dice": module.dice_score(prediction, target, reduction="none").tolist(),
                "iou": module.iou_score(prediction, target, reduction="none").tolist(),
                "bf1_euclidean": module.euclidean_boundary_f1_score(prediction, target, reduction="none").tolist(),
            }
            for i, image_id in enumerate(ids[offset:offset + args.batch_size]):
                records.append({"id": image_id, **{key: value[i] for key, value in values.items()}})
    output.mkdir(parents=True, exist_ok=True)
    with (output / "per_image_metrics.csv").open("w", encoding="utf8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    result = {"run": args.run, "seed": row["seed"], "images": len(ids),
              "complete_test_set": len(ids) == 520, "device": "cpu", "dtype": "float32",
              "python": platform.python_version(), "torch": str(module.torch.__version__),
              "checkpoint_sha256": row["checkpoint_sha256"],
              "split_sha256": hashlib.sha256(split_path.read_bytes()).hexdigest(),
              "checkpoint_metadata": metadata,
              "original_metrics": row["original_metrics"],
              "note": "New CPU replay; original GPU experiment scores remain archived unchanged."}
    result.update({key: statistics.mean(record[key] for record in records)
                   for key in ("dice", "iou", "bf1_euclidean")})
    (output / "metrics.json").write_text(json.dumps(result, indent=2), encoding="utf8")
    print(json.dumps({key: result[key] for key in
                     ("run", "images", "complete_test_set", "dice", "iou", "bf1_euclidean")}, indent=2))

if __name__ == "__main__":
    main()
